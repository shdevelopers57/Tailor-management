# Quick Start Guide - Supereme Sunspot Tailors App

## Prerequisites

Before you start, make sure you have:

1. **Android Studio** (Latest version)
   - Download from: https://developer.android.com/studio
   
2. **JDK 11 or Higher**
   - Android Studio usually includes JDK
   
3. **Android SDK** (API 34)
   - Download via Android Studio SDK Manager
   
4. **Git** (Optional, for version control)

## Step-by-Step Setup

### 1. Open Project in Android Studio

```
File → Open → Select the Supereme folder
```

### 2. Wait for Gradle Sync

Android Studio will automatically sync Gradle files. This may take 2-5 minutes on first run.

### 3. Verify SDK Installation

- Go to: **Tools → SDK Manager**
- Ensure you have:
  - Android SDK 34 (or higher)
  - Android SDK 24 (minimum required)
  - Build Tools 34.0.0

### 4. Create a Virtual Device (Emulator)

**For Testing on Emulator:**

```
Tools → Device Manager → Create Virtual Device
```

Choose:
- Device: Pixel 4 or newer
- OS: Android 12 (API 31) or higher
- RAM: 2GB minimum

### 5. Build the Project

```
Build → Make Project
```

Or use keyboard shortcut: `Ctrl + F9` (Windows/Linux) / `Cmd + F9` (Mac)

**Expected Output:**
```
Build Successful
```

### 6. Run the App

**On Emulator:**
```
Run → Run 'app'
Or press Shift + F10 (Windows/Linux) / Ctrl + R (Mac)
```

**On Physical Device:**
1. Enable Developer Mode on your Android device
2. Enable USB Debugging
3. Connect device via USB
4. Run the app (same as emulator)

### 7. First Launch

When the app launches for the first time:
1. You'll see the Home screen
2. Tap "گاہکین" (Customers) to add your first customer
3. Add customer details in Urdu
4. Start managing orders and payments

## Gradle Build Troubleshooting

### Problem: Gradle Sync Fails
**Solution:**
```
File → Invalidate Caches → Invalidate and Restart
```

### Problem: Dependency Download Error
**Solution:**
```
In Terminal:
./gradlew clean build --refresh-dependencies
```

### Problem: Memory Error During Build
**Solution:**
Add to local.properties:
```
org.gradle.jvmargs=-Xmx2048m
```

## Project Structure Overview

```
Supereme/
├── app/
│   ├── src/main/
│   │   ├── java/com/supereme/tailormanagement/  ← Main Code
│   │   └── res/                                  ← Resources
│   └── build.gradle                              ← App Config
├── build.gradle                                  ← Project Config
├── settings.gradle
├── README.md                                     ← Project Overview
└── DEVELOPMENT_GUIDE.md                         ← Detailed Guide
```

## Key File Locations

### Database Files
- Database Path: `/data/data/com.supereme.tailormanagement/databases/tailor_management.db`

### App Resources
- Strings (Urdu): `app/src/main/res/values/strings.xml`
- Colors: `app/src/main/res/values/colors.xml`
- Layouts: `app/src/main/res/layout/`

### Source Code
- Main Activities: `app/src/main/java/com/supereme/tailormanagement/ui/`
- Database: `app/src/main/java/com/supereme/tailormanagement/database/`
- ViewModels: `app/src/main/java/com/supereme/tailormanagement/viewmodel/`

## App Navigation

### Home Screen (Main Menu)
- گاہکین (Customers) - Manage customer profiles
- آرڈرز (Orders) - Create and manage orders
- ادائیگیاں (Payments) - Record payments
- رپورٹس (Reports) - View business reports
- ترتیبات (Settings) - Configure app settings

### Customer Management
1. Tap "گاہکین" button
2. Tap "+" to add new customer
3. Fill customer details:
   - نام (Name)
   - فون (Phone)
   - ای میل (Email)
   - پتہ (Address)
4. Tap "محفوظ کریں" (Save)

## Database Information

### Database Name
- `tailor_management.db`

### Tables Created
1. customers
2. orders
3. measurements
4. payments

### Backup Location
- Database is stored in app's private directory
- You can export via Android Device Monitor

## Testing the App

### Test Data Entry
1. Create test customer
   - Name: "احمد علی"
   - Phone: "03001234567"
   - Address: "کراچی"

2. Create test order
   - Type: "سوٹ"
   - Amount: "5000"
   - Status: "pending"

3. Add payment
   - Amount: "2000"
   - Method: "Cash"

## Common Tasks

### Export Database
1. Connect device/emulator
2. Open Device File Explorer (View → Tool Windows → Device File Explorer)
3. Navigate: `data → data → com.supereme.tailormanagement → databases`
4. Right-click `tailor_management.db` → Save As

### Clear App Data
1. Uninstall app: `adb uninstall com.supereme.tailormanagement`
2. Reinstall app: `Run → Run 'app'`

### View App Logs
1. View → Tool Windows → Logcat
2. Search for "SuperemeTailor" to filter logs

## Keyboard Shortcuts

### Android Studio
- **Sync Gradle**: Ctrl+Shift+I (Windows) / Cmd+Shift+I (Mac)
- **Run App**: Shift+F10 (Windows) / Ctrl+R (Mac)
- **Build Project**: Ctrl+F9 (Windows) / Cmd+F9 (Mac)
- **Open Run Configuration**: Shift+Alt+F10 (Windows) / Ctrl+Alt+R (Mac)

## Next Steps

1. **Understand Database Schema**: Read DEVELOPMENT_GUIDE.md
2. **Explore Code**: Browse through source files
3. **Add Features**: Implement missing modules (Orders, Payments, etc.)
4. **Customize**: Update colors, branding, texts

## Support Resources

- **Android Documentation**: https://developer.android.com/docs
- **Room Database**: https://developer.android.com/training/data-storage/room
- **Material Design**: https://material.io/develop/android
- **Android Lifecycle**: https://developer.android.com/guide/components/activities/activity-lifecycle

## Build Commands (Command Line)

```bash
# Clean build
./gradlew clean build

# Build only
./gradlew build

# Build and install on emulator/device
./gradlew installDebug

# Run specific activity
adb shell am start -n com.supereme.tailormanagement/.MainActivity

# View logs
adb logcat
```

## Next Features to Implement

1. ✅ Database Setup
2. ✅ Customer Management UI
3. ⏳ Order Management Full Feature
4. ⏳ Measurements Recording
5. ⏳ Payment Management
6. ⏳ Reports & Analytics
7. ⏳ Settings Configuration

---

**Happy Coding! 🚀**

For detailed information, please refer to `DEVELOPMENT_GUIDE.md`
