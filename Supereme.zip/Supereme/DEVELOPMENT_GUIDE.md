# Supereme Sunspot Tailors App - Development Guide

## Project Overview

This is a professional Android application developed for **Supereme Sunspot Tailors** to manage all tailor shop operations. The app is completely offline and doesn't require internet connectivity.

## Architecture Overview

### MVVM Pattern
The application follows the **Model-View-ViewModel (MVVM)** architectural pattern:

```
UI Layer (Activities/Fragments)
         ↓
ViewModel Layer (Business Logic)
         ↓
Repository Layer (Data Access)
         ↓
Database Layer (Room/SQLite)
```

### Components

#### 1. **Database Layer**
- **TailorManagementDatabase**: Main database class
- **Entities**: Customer, Order, Measurement, Payment
- **DAOs**: CustomerDao, OrderDao, MeasurementDao, PaymentDao
- **Converters**: DateConverter for date/time handling

#### 2. **Repository Layer**
- Abstraction layer between database and UI
- Handles all database operations
- Examples: CustomerRepository, OrderRepository, etc.

#### 3. **ViewModel Layer**
- Business logic implementation
- Lifecycle-aware data handling
- LiveData for reactive UI updates
- Examples: MainViewModel, CustomerViewModel

#### 4. **UI Layer**
- Activities: MainActivity, CustomerListActivity, AddCustomerActivity, etc.
- Adapters: RecyclerView adapters for displaying lists
- Layouts: XML layouts with Material Design

## Database Schema

### Tables

#### **customers**
```sql
id (PrimaryKey, AutoIncrement)
name (String) - Customer full name
phone (String) - Phone number
email (String) - Email address
address (String) - Home address
city (String) - City
country (String) - Country
createdDate (Date)
lastModified (Date)
isActive (Boolean) - For soft delete
```

#### **orders**
```sql
id (PrimaryKey, AutoIncrement)
customerId (ForeignKey to customers.id)
orderType (String) - Suit, Shirt, Pant, etc.
description (String) - Work description
orderDate (Date)
deliveryDate (Date)
amount (Double)
advance (Double) - Advance payment
remaining (Double) - Remaining amount
status (String) - pending, designing, tailoring, fitting, completed, delivered, cancelled
createdDate (Date)
lastModified (Date)
```

#### **measurements**
```sql
id (PrimaryKey, AutoIncrement)
customerId (ForeignKey to customers.id)
orderId (ForeignKey to orders.id)
chest (Double)
waist (Double)
hips (Double)
shoulder (Double)
sleeveLength (Double)
totalLength (Double)
inseam (Double)
neckSize (Double)
armholeDepth (Double)
backWidth (Double)
frontWidth (Double)
notes (String)
```

#### **payments**
```sql
id (PrimaryKey, AutoIncrement)
customerId (ForeignKey to customers.id)
orderId (ForeignKey to orders.id)
amount (Double)
paymentDate (Date)
paymentMethod (String) - cash, card, bank_transfer
notes (String)
createdDate (Date)
```

## Key Features Implementation

### 1. Customer Management
**Location**: `ui/CustomerListActivity.java`, `ui/AddCustomerActivity.java`

**Features**:
- Add new customers with complete details
- Edit existing customer information
- Delete customers (soft delete for data integrity)
- Search customers by name
- View customer history

**Implementation Notes**:
- Uses `CustomerAdapter` for displaying list in RecyclerView
- `CustomerViewModel` handles business logic
- `CustomerRepository` manages database operations

### 2. Order Management
**Location**: `ui/OrderListActivity.java`, `ui/AddOrderActivity.java`

**Status Flow**:
```
pending → designing → tailoring → fitting → completed → delivered
                                                      ↓
                                                  cancelled
```

**Key Methods**:
- Get orders by customer
- Get orders by status
- Update order amount and status
- Calculate pending amount

### 3. Measurements Recording
**Location**: To be implemented

**Features**:
- Store standard measurements (chest, waist, etc.)
- Store custom measurements
- Link measurements to orders
- Store tailor notes

### 4. Payment Tracking
**Location**: `ui/PaymentActivity.java`

**Features**:
- Record payments for orders
- Multiple payment methods support
- Track payment history
- Calculate remaining balance

### 5. Reports & Analytics
**Location**: `ui/ReportsActivity.java`

**Available Reports**:
- Daily income report
- Monthly income report
- Pending orders summary
- Completed orders summary
- Customer payment status

## Urdu Language Implementation

The app uses Urdu as the primary language. All strings are defined in `values/strings.xml`:

### String Resource Format
```xml
<string name="key">Urdu Text</string>
```

### Example Strings
```xml
<string name="customers">گاہکین</string>
<string name="add_customer">گاہک شامل کریں</string>
<string name="orders">آرڈرز</string>
```

### Language File Structure
- `values/strings.xml`: Contains all UI text in Urdu

## Building and Debugging

### Build Process
1. **Sync Gradle**: File → Sync Now
2. **Build Project**: Build → Make Project
3. **Run App**: Run → Run 'app'

### Common Build Issues

**Issue**: Gradle dependency errors
**Solution**: 
- Update Android Gradle Plugin
- Clear gradle cache: `./gradlew clean`

**Issue**: Compilation errors
**Solution**:
- Check Java version (JDK 11+)
- Ensure all imports are correct
- Run `./gradlew clean build`

### Testing

Currently, the app includes basic unit test setup. To add tests:

```java
// Test class example
@RunWith(AndroidTestRunner.class)
public class CustomerDaoTest {
    
    private TailorManagementDatabase db;
    private CustomerDao customerDao;
    
    @Before
    public void setUp() {
        db = Room.inMemoryDatabaseBuilder(
            InstrumentationRegistry.getInstrumentation().getTargetContext(),
            TailorManagementDatabase.class)
            .allowMainThreadQueries()
            .build();
        customerDao = db.customerDao();
    }
    
    @Test
    public void insertAndGetCustomer() {
        Customer customer = new Customer("Test", "03001234567", "test@email.com", "Address");
        long id = customerDao.insert(customer);
        Customer retrieved = customerDao.getCustomerByIdSync((int) id);
        assertEquals("Test", retrieved.name);
    }
}
```

## Color Scheme

### Primary Colors
- **Primary**: #1F6E3F (Green)
- **Primary Dark**: #155936
- **Primary Light**: #4A9B5F

### Secondary Colors
- **Secondary**: #FF6B35 (Orange)
- **Accent**: #FFC107 (Amber)

### Status Colors
- **Pending**: #FFC107 (Yellow)
- **Designing**: #2196F3 (Blue)
- **Tailoring**: #FF9800 (Orange)
- **Fitting**: #9C27B0 (Purple)
- **Completed**: #4CAF50 (Green)
- **Delivered**: #00BCD4 (Cyan)
- **Cancelled**: #F44336 (Red)

## Material Design Components Used

1. **MaterialCardView**: For card layouts
2. **TextInputLayout**: For text input fields
3. **FloatingActionButton**: For primary actions
4. **MaterialButton**: For action buttons
5. **RecyclerView**: For list display
6. **Toolbar**: For app header

## Dependencies

```gradle
// AndroidX
androidx.appcompat:appcompat:1.6.1
androidx.constraintlayout:constraintlayout:2.1.4
androidx.lifecycle:lifecycle-viewmodel:2.6.1
androidx.lifecycle:lifecycle-livedata:2.6.1

// Room Database
androidx.room:room-runtime:2.5.2
androidx.room:room-compiler:2.5.2

// Material Design
com.google.android.material:material:1.9.0

// RecyclerView
androidx.recyclerview:recyclerview:1.3.0

// JSON
com.google.code.gson:gson:2.10.1
```

## Future Development Roadmap

### Phase 1: Core Features (Current)
- ✅ Customer Management
- ✅ Order Management (Basic)
- ✅ Database structure
- ⏳ Measurements Recording
- ⏳ Payment Management
- ⏳ Reports & Analytics

### Phase 2: Enhanced Features
- Photo Management (Order designs/before-after)
- SMS Notifications for customers
- Backup & Restore functionality
- Advanced search filters

### Phase 3: Business Intelligence
- Analytics Dashboard
- Monthly financial reports
- Customer spending analytics
- Peak season analysis

### Phase 4: Sync & Cloud
- Cloud backup option
- Multi-device synchronization
- Automated backup to cloud storage

## Performance Optimization

### Database Optimization
- Use indexed queries for frequently searched fields
- Implement pagination for large lists
- Use Room's async operations

### UI Optimization
- Load images asynchronously
- Implement pagination in RecyclerView
- Use ViewBinding for better performance

## Security Considerations

1. **Data Privacy**: All data stored locally
2. **No Internet**: No external data transmission
3. **Soft Delete**: Deleted records marked as inactive (recoverable)
4. **Database Encryption**: Future enhancement for sensitive data

## Troubleshooting Guide

### App Crashes
1. Check logcat for errors
2. Verify all activities are declared in AndroidManifest.xml
3. Check for missing ViewModel initialization

### Database Issues
1. Clear app data: Settings → Apps → Supereme → Storage → Clear
2. Rebuild database by uninstalling and reinstalling
3. Check Room database migration if upgrading database version

### UI Not Displaying
1. Verify layout XML syntax
2. Check if activities are properly initialized
3. Ensure correct activity names in AndroidManifest.xml

## Contact & Support

For technical support or questions:
- Check the README.md file
- Review code comments
- Check Android Studio's Logcat for error messages

---

**Document Version**: 1.0  
**Last Updated**: 2024  
**App Version**: 1.0.0
