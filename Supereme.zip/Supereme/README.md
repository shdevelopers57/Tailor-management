# Supereme Sunspot Tailors - Management App

## Overview

This is an offline Android application for managing tailor shop operations for **Supereme Sunspot Tailors**. The app is designed with **Urdu language support** as the primary language interface and provides comprehensive tailor management features.

## Features

### 1. **Customer Management**
- Add, edit, and delete customer profiles
- Store customer information including:
  - Full name
  - Phone number
  - Email address
  - Home address
  - City and Country
- Search customers by name
- View customer details and order history

### 2. **Order Management**
- Create and manage tailoring orders
- Track order status through different stages:
  - **Pending** - New order
  - **Designing** - Design phase
  - **Tailoring** - Sewing phase
  - **Fitting** - Fitting with customer
  - **Completed** - Tailoring finished
  - **Delivered** - Order delivered to customer
  - **Cancelled** - Order cancelled
- Store order details:
  - Order type (Suit, Shirt, Pant, etc.)
  - Description of work
  - Order date and delivery date
  - Order amount

### 3. **Measurements**
- Record customer body measurements including:
  - Chest, waist, hips, shoulder
  - Sleeve length, total length, inseam
  - Additional custom measurements
  - Notes for tailor reference

### 4. **Payment Management**
- Record and track payments
- Payment methods support:
  - Cash
  - Card
  - Bank transfer
- Track payment history per customer/order
- Calculate pending amounts

### 5. **Reports**
- Generate daily, monthly, and income reports
- View pending orders summary
- View completed orders summary
- Track total income and pending amounts

### 6. **Settings**
- Configure shop information:
  - Shop name
  - Shop phone number
  - Shop address
- Backup and restore data
- Currency settings
- About information

## Technology Stack

- **Language**: Java (Android)
- **Database**: SQLite (Room Database - Offline support)
- **UI Framework**: AndroidX with Material Design 3
- **Architecture**: MVVM (Model-View-ViewModel)
- **Target API**: Android 34 (API Level 34)
- **Minimum API**: Android 24 (API Level 24)

## Project Structure

```
app/
├── src/
│   └── main/
│       ├── AndroidManifest.xml
│       ├── java/com/supereme/tailormanagement/
│       │   ├── MainActivity.java
│       │   ├── database/
│       │   │   ├── TailorManagementDatabase.java
│       │   │   ├── converter/
│       │   │   │   └── DateConverter.java
│       │   │   ├── dao/
│       │   │   │   ├── CustomerDao.java
│       │   │   │   ├── OrderDao.java
│       │   │   │   ├── MeasurementDao.java
│       │   │   │   └── PaymentDao.java
│       │   │   └── entity/
│       │   │       ├── Customer.java
│       │   │       ├── Order.java
│       │   │       ├── Measurement.java
│       │   │       └── Payment.java
│       │   ├── repository/
│       │   │   ├── CustomerRepository.java
│       │   │   ├── OrderRepository.java
│       │   │   ├── MeasurementRepository.java
│       │   │   └── PaymentRepository.java
│       │   ├── viewmodel/
│       │   │   ├── MainViewModel.java
│       │   │   └── CustomerViewModel.java
│       │   ├── ui/
│       │   │   ├── CustomerListActivity.java
│       │   │   ├── AddCustomerActivity.java
│       │   │   ├── OrderListActivity.java
│       │   │   ├── AddOrderActivity.java
│       │   │   ├── PaymentActivity.java
│       │   │   ├── ReportsActivity.java
│       │   │   └── SettingsActivity.java
│       │   └── adapter/
│       │       └── CustomerAdapter.java
│       └── res/
│           ├── layout/
│           │   ├── activity_main.xml
│           │   ├── activity_customer_list.xml
│           │   ├── activity_add_customer.xml
│           │   ├── activity_order_list.xml
│           │   ├── activity_add_order.xml
│           │   ├── activity_payment.xml
│           │   ├── activity_reports.xml
│           │   └── activity_settings.xml
│           └── values/
│               ├── strings.xml (Urdu & English)
│               ├── colors.xml
│               └── styles.xml
├── build.gradle
└── AndroidManifest.xml
```

## Language Support

The app is fully localized in **Urdu** with English labels for technical terms. All user-facing text is in Urdu including:
- Menu items
- Form labels
- Button text
- Status messages
- Dialog prompts

### Urdu Text Examples:
- App Name: "سپریم سن اسپاٹ ٹیلرز"
- Home: "ہوم"
- Customers: "گاہکین"
- Orders: "آرڈرز"
- Payments: "ادائیگیاں"

## Installation & Setup

### Prerequisites
- Android Studio (Latest version)
- Java Development Kit (JDK) 11 or higher
- Android SDK (API 34 and API 24+)

### Steps to Build

1. **Clone or open the project in Android Studio**
   ```bash
   cd Supereme
   ```

2. **Sync Gradle dependencies**
   - In Android Studio, go to File → Sync Now
   - Wait for all dependencies to download

3. **Build the project**
   - Go to Build → Make Project
   - Or press `Ctrl+F9` (Windows/Linux) / `Cmd+F9` (Mac)

4. **Run the app**
   - Connect an Android device or use an emulator
   - Click Run → Run 'app'
   - Or press `Shift+F10` (Windows/Linux) / `Ctrl+R` (Mac)

## Database

The app uses **SQLite Database** (via Android Room) for offline data storage. The database includes tables for:

- **customers**: Stores customer information
- **orders**: Stores order details and status
- **measurements**: Stores customer measurements for each order
- **payments**: Stores payment records and transaction history

All data is stored locally on the device and synced offline (no internet required).

## Key Features Implementation

### Offline Functionality
- All data is stored in SQLite database
- No internet connection required
- Data persists across app sessions

### MVVM Architecture
- **Model**: Database entities and repositories
- **View**: Activities and layout XMLs
- **ViewModel**: Business logic and data handling

### Material Design
- Modern UI with Material Design 3
- Consistent color scheme (Green primary color)
- Responsive layouts for different screen sizes
- Smooth transitions and animations

## Future Enhancements

1. **Advanced Reporting**
   - PDF export functionality
   - Email reports
   - Monthly financial summaries

2. **Photo Management**
   - Store order photos/designs
   - Before/after photos

3. **Notifications**
   - Delivery reminders
   - Payment reminders

4. **Backup & Sync**
   - Cloud backup option
   - Data synchronization across devices

5. **Multilingual Support**
   - Additional language options

## Permissions Required

- `READ_CONTACTS`: For quick customer phone lookup
- `CALL_PHONE`: For direct calling customers
- `SEND_SMS`: For SMS notifications

## Version Information

- **Version**: 1.0.0
- **Build Tools**: 34.0.0
- **Target SDK**: 34
- **Minimum SDK**: 24

## Support

For issues, bugs, or feature requests, please contact development team or create an issue in the project repository.

## License

All rights reserved for Supereme Sunspot Tailors.

---

**App Name in Urdu**: سپریم سن اسپاٹ ٹیلرز (Supereme Sunspot Tailors)

**Created**: 2024
**Language**: Java/Android
**Platform**: Android Mobile
