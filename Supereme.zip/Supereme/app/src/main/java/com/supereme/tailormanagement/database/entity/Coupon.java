package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "coupons")
public class Coupon {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String code;
    public String description;
    public double discountValue;
    public String discountType; // percentage or fixed
    public Date validFrom;
    public Date validUpto;
    public int usageLimit;
    public int usageCount;
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public Coupon() {
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
        this.usageCount = 0;
    }
    
    @Ignore
    public Coupon(String code, double discountValue, String discountType) {
        this.code = code;
        this.discountValue = discountValue;
        this.discountType = discountType;
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
        this.usageCount = 0;
    }
    
    public boolean isValid() {
        Date now = new Date();
        // Coupon is valid if:
        // 1. It's marked as active
        // 2. Today's date is on or after validFrom date (or validFrom is null)
        // 3. Today's date is before or on validUpto date (or validUpto is null)
        // 4. Usage limit hasn't been reached (or no limit set)
        boolean isDateRangeValid = (validFrom == null || !validFrom.after(now)) &&   // validFrom has passed or is null
                                   (validUpto == null || !validUpto.before(now));     // validUpto hasn't passed or is null
        boolean isUsageValid = usageLimit <= 0 || usageCount < usageLimit;
        return isActive && isDateRangeValid && isUsageValid;
    }
    
    public double getDiscountAmount(double baseAmount) {
        if ("percentage".equals(discountType)) {
            return baseAmount * (discountValue / 100);
        } else {
            return discountValue;
        }
    }
    
    @Override
    public String toString() {
        return code + " - " + discountValue + (discountType.equals("percentage") ? "%" : "");
    }
}
