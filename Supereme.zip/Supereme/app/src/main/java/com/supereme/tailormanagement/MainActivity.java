package com.supereme.tailormanagement;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.ui.CustomerListActivity;
import com.supereme.tailormanagement.ui.MeasurementActivity;
import com.supereme.tailormanagement.ui.OrderListActivity;
import com.supereme.tailormanagement.ui.PaymentActivity;
import com.supereme.tailormanagement.ui.ReportsActivity;
import com.supereme.tailormanagement.ui.SettingsActivity;
import com.supereme.tailormanagement.ui.ClothTypeListActivity;
import com.supereme.tailormanagement.ui.ExpenseListActivity;
import com.supereme.tailormanagement.ui.InvoiceListActivity;
import com.supereme.tailormanagement.ui.CouponListActivity;
import com.supereme.tailormanagement.viewmodel.MainViewModel;

public class MainActivity extends AppCompatActivity {
    
    private static final int PERMISSION_REQUEST_CODE = 100;
    private MainViewModel mainViewModel;
    private TextView tvTotalCustomers, tvPendingOrders, tvTotalRevenue, tvTotalPaid;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_main);
            
            // Request permissions on Android 6.0+
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestRequiredPermissions();
            } else {
                // Permissions automatically granted on Android 5.1 and below
                initializeApp();
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error in onCreate", e);
            Toast.makeText(this, "خرابی: " + e.getMessage(), Toast.LENGTH_LONG).show();
            finish();
        }
    }
    
    private void requestRequiredPermissions() {
        String[] permissions = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        
        boolean needsPermission = false;
        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission) 
                    != PackageManager.PERMISSION_GRANTED) {
                needsPermission = true;
                break;
            }
        }
        
        if (needsPermission) {
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        } else {
            initializeApp();
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }
            
            if (allGranted) {
                initializeApp();
            } else {
                Toast.makeText(this, "اجازتیں نہیں ملی، مگر ایپ کھلی رہے گی", Toast.LENGTH_SHORT).show();
                initializeApp();
            }
        }
    }
    
    private void initializeApp() {
        try {
            initializeViews();
            mainViewModel = new ViewModelProvider(this).get(MainViewModel.class);
            setupClickListeners();
            observeData();
        } catch (Exception e) {
            Log.e("MainActivity", "Error initializing app", e);
            initializeViews();
            if (tvTotalCustomers != null) tvTotalCustomers.setText("0");
            if (tvPendingOrders != null) tvPendingOrders.setText("0");
            if (tvTotalRevenue != null) tvTotalRevenue.setText("Rs. 0");
            if (tvTotalPaid != null) tvTotalPaid.setText("Rs. 0");
            Toast.makeText(this, "ایپ کھلی ہوئی ہے، مگر ابتدائی ڈیٹا لوڈ نہیں ہو سکا", Toast.LENGTH_LONG).show();
        }
    }
    
    private void initializeViews() {
        tvTotalCustomers = findViewById(R.id.tv_total_customers);
        tvPendingOrders = findViewById(R.id.tv_pending_orders);
        tvTotalRevenue = findViewById(R.id.tv_total_revenue);
        tvTotalPaid = findViewById(R.id.tv_total_paid);
    }
    
    private void setupClickListeners() {
        Button btnCustomers = findViewById(R.id.btn_customers);
        Button btnOrders = findViewById(R.id.btn_orders);
        Button btnMeasurements = findViewById(R.id.btn_measurements);
        Button btnPayments = findViewById(R.id.btn_payments);
        Button btnReports = findViewById(R.id.btn_reports);
        Button btnSettings = findViewById(R.id.btn_settings);
        Button btnClothTypes = findViewById(R.id.btn_cloth_types);
        Button btnExpenses = findViewById(R.id.btn_expenses);
        Button btnInvoices = findViewById(R.id.btn_invoices);
        Button btnCoupons = findViewById(R.id.btn_coupons);
        
        if (btnCustomers != null) {
            btnCustomers.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, CustomerListActivity.class));
            });
        }
        
        if (btnOrders != null) {
            btnOrders.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, OrderListActivity.class));
            });
        }
        
        if (btnMeasurements != null) {
            btnMeasurements.setOnClickListener(v -> {
                // Navigate to customers first to select a customer for viewing measurements
                Intent intent = new Intent(MainActivity.this, CustomerListActivity.class);
                intent.putExtra("showMeasurements", true);
                startActivity(intent);
            });
        }
        
        if (btnPayments != null) {
            btnPayments.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, PaymentActivity.class));
            });
        }
        
        if (btnClothTypes != null) {
            btnClothTypes.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, ClothTypeListActivity.class));
            });
        }
        
        if (btnExpenses != null) {
            btnExpenses.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, ExpenseListActivity.class));
            });
        }
        
        if (btnInvoices != null) {
            btnInvoices.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, InvoiceListActivity.class));
            });
        }
        
        if (btnCoupons != null) {
            btnCoupons.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, CouponListActivity.class));
            });
        }
        
        if (btnReports != null) {
            btnReports.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, ReportsActivity.class));
            });
        }
        
        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            });
        }
    }
    
    private void observeData() {
        if (mainViewModel == null) return;
        
        mainViewModel.getCustomerCount().observe(this, count -> {
            if (tvTotalCustomers != null) {
                tvTotalCustomers.setText(String.valueOf(count != null ? count : 0));
            }
        });
        
        mainViewModel.getPendingOrderCount().observe(this, count -> {
            if (tvPendingOrders != null) {
                tvPendingOrders.setText(String.valueOf(count != null ? count : 0));
            }
        });
        
        mainViewModel.getTotalCompletedAmount().observe(this, amount -> {
            if (tvTotalRevenue != null) {
                if (amount != null && !amount.isNaN()) {
                    tvTotalRevenue.setText(String.format("Rs. %.0f", amount));
                } else {
                    tvTotalRevenue.setText("Rs. 0");
                }
            }
        });
        
        mainViewModel.getTotalPayments().observe(this, amount -> {
            if (tvTotalPaid != null) {
                if (amount != null && !amount.isNaN()) {
                    tvTotalPaid.setText(String.format("Rs. %.0f", amount));
                } else {
                    tvTotalPaid.setText("Rs. 0");
                }
            }
        });
    }
}
