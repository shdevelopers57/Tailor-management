package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Customer;
import java.util.List;

@Dao
public interface CustomerDao {
    
    @Insert
    long insert(Customer customer);
    
    @Update
    int update(Customer customer);
    
    @Delete
    int delete(Customer customer);
    
    @Query("SELECT * FROM customers WHERE id = :id")
    LiveData<Customer> getCustomerById(int id);
    
    @Query("SELECT * FROM customers WHERE id = :id")
    Customer getCustomerByIdSync(int id);
    
    @Query("SELECT * FROM customers WHERE isActive = 1 ORDER BY name ASC")
    LiveData<List<Customer>> getAllCustomers();
    
    @Query("SELECT * FROM customers WHERE isActive = 1 ORDER BY name ASC")
    List<Customer> getAllCustomersSync();
    
    @Query("SELECT * FROM customers WHERE name LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY name ASC")
    LiveData<List<Customer>> searchCustomers(String searchQuery);
    
    @Query("SELECT * FROM customers WHERE phone LIKE '%' || :phone || '%'")
    Customer getCustomerByPhone(String phone);
    
    @Query("SELECT COUNT(*) FROM customers WHERE isActive = 1")
    LiveData<Integer> getCustomerCount();
    
    @Query("DELETE FROM customers WHERE id = :id")
    void deleteById(int id);
    
    @Query("SELECT * FROM customers ORDER BY createdDate DESC LIMIT 10")
    LiveData<List<Customer>> getRecentCustomers();
}
