package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Invoice;
import java.util.List;

@Dao
public interface InvoiceDao {
    
    @Insert
    long insert(Invoice invoice);
    
    @Update
    int update(Invoice invoice);
    
    @Delete
    int delete(Invoice invoice);
    
    @Query("SELECT * FROM invoices WHERE id = :id")
    LiveData<Invoice> getInvoiceById(int id);
    
    @Query("SELECT * FROM invoices WHERE id = :id")
    Invoice getInvoiceByIdSync(int id);
    
    @Query("SELECT * FROM invoices WHERE invoiceNumber = :invoiceNumber")
    Invoice getInvoiceByNumber(String invoiceNumber);
    
    @Query("SELECT * FROM invoices WHERE isActive = 1 ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getAllInvoices();
    
    @Query("SELECT * FROM invoices WHERE isActive = 1 ORDER BY invoiceDate DESC")
    List<Invoice> getAllInvoicesSync();
    
    @Query("SELECT * FROM invoices WHERE customerId = :customerId AND isActive = 1 ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getInvoicesByCustomer(int customerId);
    
    @Query("SELECT * FROM invoices WHERE orderId = :orderId AND isActive = 1")
    Invoice getInvoiceByOrder(int orderId);
    
    @Query("SELECT * FROM invoices WHERE status = :status AND isActive = 1 ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> getInvoicesByStatus(String status);
    
    @Query("SELECT * FROM invoices WHERE invoiceNumber LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY invoiceDate DESC")
    LiveData<List<Invoice>> searchInvoices(String searchQuery);
    
    @Query("SELECT SUM(totalAmount) FROM invoices WHERE status != 'cancelled' AND isActive = 1")
    LiveData<Double> getTotalInvoiceAmount();
    
    @Query("SELECT SUM(totalAmount) FROM invoices WHERE status = 'paid' AND isActive = 1")
    LiveData<Double> getTotalPaidAmount();
    
    @Query("SELECT COUNT(*) FROM invoices WHERE isActive = 1")
    LiveData<Integer> getInvoiceCount();
    
    @Query("DELETE FROM invoices WHERE id = :id")
    void deleteById(int id);
}
