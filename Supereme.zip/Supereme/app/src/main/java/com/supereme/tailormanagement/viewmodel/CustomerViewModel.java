package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.supereme.tailormanagement.database.entity.Customer;
import com.supereme.tailormanagement.repository.CustomerRepository;
import java.util.List;

public class CustomerViewModel extends AndroidViewModel {
    
    private CustomerRepository customerRepository;
    private MutableLiveData<List<Customer>> customersLiveData;
    private LiveData<List<Customer>> currentData;
    
    public CustomerViewModel(Application application) {
        super(application);
        customerRepository = new CustomerRepository(application);
        customersLiveData = new MutableLiveData<>();
        currentData = customerRepository.getAllCustomers();
    }
    
    public LiveData<List<Customer>> getAllCustomers() {
        currentData = customerRepository.getAllCustomers();
        return currentData;
    }
    
    public LiveData<List<Customer>> searchCustomers(String query) {
        currentData = customerRepository.searchCustomers(query);
        return currentData;
    }
    
    public void insertCustomer(Customer customer) {
        customerRepository.insert(customer);
    }
    
    public void updateCustomer(Customer customer) {
        customerRepository.update(customer);
    }
    
    public void deleteCustomer(Customer customer) {
        customerRepository.delete(customer);
    }
    
    public LiveData<Customer> getCustomerById(int id) {
        return customerRepository.getCustomerById(id);
    }
    
    public Customer getCustomerByPhoneSync(String phone) {
        return customerRepository.getCustomerByPhoneSync(phone);
    }
}
