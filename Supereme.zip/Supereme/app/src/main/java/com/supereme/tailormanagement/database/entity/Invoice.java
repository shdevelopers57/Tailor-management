package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "invoices", 
        foreignKeys = {
            @ForeignKey(entity = Customer.class, 
                    parentColumns = "id", 
                    childColumns = "customerId", 
                    onDelete = ForeignKey.CASCADE),
            @ForeignKey(entity = Order.class, 
                    parentColumns = "id", 
                    childColumns = "orderId", 
                    onDelete = ForeignKey.CASCADE),
            @ForeignKey(entity = Coupon.class, 
                    parentColumns = "id", 
                    childColumns = "couponId", 
                    onDelete = ForeignKey.SET_NULL)
        },
        indices = {@Index("customerId"), @Index("orderId"), @Index("couponId")})
public class Invoice {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public int customerId;
    public int orderId;
    public String invoiceNumber;
    public Date invoiceDate;
    public Date dueDate;
    public double subtotal;
    public double taxAmount;
    public double discountAmount;
    public Integer couponId;
    public double totalAmount;
    public String status; // draft, issued, paid, partially_paid, cancelled, overdue
    public String notes;
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public Invoice() {
        this.invoiceDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.status = "draft";
        this.isActive = true;
    }
    
    @Ignore
    public Invoice(int customerId, int orderId, String invoiceNumber) {
        this.customerId = customerId;
        this.orderId = orderId;
        this.invoiceNumber = invoiceNumber;
        this.invoiceDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.status = "draft";
        this.isActive = true;
    }
    
    public void calculateTotal() {
        this.totalAmount = this.subtotal + this.taxAmount - this.discountAmount;
        if (this.totalAmount < 0) {
            this.totalAmount = 0;
        }
    }
    
    @Override
    public String toString() {
        return "Invoice{" +
                "invoiceNumber='" + invoiceNumber + '\'' +
                ", totalAmount=" + totalAmount +
                ", status='" + status + '\'' +
                '}';
    }
}
