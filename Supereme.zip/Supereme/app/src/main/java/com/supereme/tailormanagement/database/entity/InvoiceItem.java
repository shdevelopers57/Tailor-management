package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "invoice_items", 
        foreignKeys = {
            @ForeignKey(entity = Invoice.class, 
                    parentColumns = "id", 
                    childColumns = "invoiceId", 
                    onDelete = ForeignKey.CASCADE),
            @ForeignKey(entity = ClothType.class, 
                    parentColumns = "id", 
                    childColumns = "clothTypeId", 
                    onDelete = ForeignKey.SET_NULL)
        },
        indices = {@Index("invoiceId"), @Index("clothTypeId")})
public class InvoiceItem {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public int invoiceId;
    public String description;
    public Integer clothTypeId;
    public int quantity;
    public double unitPrice;
    public double amount;
    public Date createdDate;
    public Date lastModified;
    
    public InvoiceItem() {
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.quantity = 1;
    }
    
    @Ignore
    public InvoiceItem(int invoiceId, String description, double unitPrice, int quantity) {
        this.invoiceId = invoiceId;
        this.description = description;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
        this.createdDate = new Date();
        this.lastModified = new Date();
        calculateAmount();
    }
    
    public void calculateAmount() {
        this.amount = this.unitPrice * this.quantity;
    }
    
    @Override
    public String toString() {
        return "InvoiceItem{" +
                "description='" + description + '\'' +
                ", quantity=" + quantity +
                ", amount=" + amount +
                '}';
    }
}
