package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "customers")
public class Customer {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String name;
    public String phone;
    public String email;
    public String address;
    public String city;
    public String country;
    public Date createdDate;
    public Date lastModified;
    public boolean isActive;
    
    public Customer() {
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Ignore
    public Customer(String name, String phone, String email, String address) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
