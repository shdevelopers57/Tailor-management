package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.MainActivity;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.util.SerialNumberGenerator;
import com.supereme.tailormanagement.viewmodel.CustomerViewModel;
import com.supereme.tailormanagement.viewmodel.OrderViewModel;
import com.supereme.tailormanagement.database.entity.Customer;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class OrderSummaryActivity extends AppCompatActivity {
    
    private CustomerViewModel customerViewModel;
    private OrderViewModel orderViewModel;
    private TextView tvCustomerName, tvCustomerPhone, tvSerialNumber, tvDeliveryDate, tvNumberOfSuits, tvOrderDate;
    private CardView cvTicket;
    private Button btnSaveToPhone, btnFinish, btnNewOrder;
    private int customerId;
    private String serialNumber;
    private Customer currentCustomer;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);
        
        customerViewModel = new ViewModelProvider(this).get(CustomerViewModel.class);
        orderViewModel = new ViewModelProvider(this).get(OrderViewModel.class);
        
        initializeViews();
        
        if (getIntent().hasExtra("customer_id")) {
            customerId = getIntent().getIntExtra("customer_id", -1);
            loadOrderSummary();
        } else {
            Toast.makeText(this, R.string.error_loading_data, Toast.LENGTH_SHORT).show();
            finish();
        }
        
        setupClickListeners();
    }
    
    private void initializeViews() {
        tvCustomerName = findViewById(R.id.tv_customer_name);
        tvCustomerPhone = findViewById(R.id.tv_customer_phone);
        tvSerialNumber = findViewById(R.id.tv_serial_number);
        tvDeliveryDate = findViewById(R.id.tv_delivery_date);
        tvNumberOfSuits = findViewById(R.id.tv_number_of_suits);
        tvOrderDate = findViewById(R.id.tv_order_date);
        cvTicket = findViewById(R.id.cv_ticket);
        btnSaveToPhone = findViewById(R.id.btn_save_to_phone);
        btnFinish = findViewById(R.id.btn_finish);
        btnNewOrder = findViewById(R.id.btn_new_order);
    }
    
    private void loadOrderSummary() {
        customerViewModel.getCustomerById(customerId).observe(this, customer -> {
            if (customer != null) {
                currentCustomer = customer;
                tvCustomerName.setText(customer.name);
                tvCustomerPhone.setText(customer.phone != null ? customer.phone : "N/A");
                
                // Generate serial number
                serialNumber = SerialNumberGenerator.generateSerialNumber(customerId);
                tvSerialNumber.setText("Token: " + serialNumber);
                tvOrderDate.setText(new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date()));
                
                // Load orders for this customer to count suits and get delivery date
                orderViewModel.getOrdersByCustomerId(customerId).observe(OrderSummaryActivity.this, orders -> {
                    if (orders != null && !orders.isEmpty()) {
                        tvNumberOfSuits.setText(String.valueOf(orders.size()));
                        
                        // Get the latest order's delivery date
                        if (orders.get(orders.size() - 1).deliveryDate != null) {
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                            tvDeliveryDate.setText(sdf.format(orders.get(orders.size() - 1).deliveryDate));
                        } else {
                            // Default to 7 days from now
                            Date deliveryDate = new Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000);
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                            tvDeliveryDate.setText(sdf.format(deliveryDate));
                        }
                    } else {
                        tvNumberOfSuits.setText("0");
                        Date deliveryDate = new Date(System.currentTimeMillis() + 7 * 24 * 60 * 60 * 1000);
                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                        tvDeliveryDate.setText(sdf.format(deliveryDate));
                    }
                });
            }
        });
    }
    
    private void setupClickListeners() {
        btnSaveToPhone.setOnClickListener(v -> saveTicketToPhone());
        btnFinish.setOnClickListener(v -> {
            startActivity(new Intent(OrderSummaryActivity.this, MainActivity.class));
            finish();
        });
        btnNewOrder.setOnClickListener(v -> {
            Intent intent = new Intent(OrderSummaryActivity.this, AddOrderActivity.class);
            intent.putExtra("customer_id", customerId);
            startActivity(intent);
            finish();
        });
    }
    
    private void saveTicketToPhone() {
        try {
            // Check permission on Android 6.0+
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                    return;
                }
            }
            
            // Create bitmap from the ticket card view
            Bitmap bitmap = getBitmapFromView(cvTicket);
            
            // Save to external storage
            String filename = "ticket_" + serialNumber.replace(":", "") + "_" + System.currentTimeMillis() + ".png";
            File path = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Supereme");
            
            if (!path.exists()) {
                path.mkdirs();
            }
            
            File file = new File(path, filename);
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            fos.close();
            
            Toast.makeText(this, getString(R.string.ticket_saved_to) + " " + path.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.error_saving_ticket) + ": " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    
    private Bitmap getBitmapFromView(CardView view) {
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);
        return bitmap;
    }
}
