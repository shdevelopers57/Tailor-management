package com.supereme.tailormanagement.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Invoice;
import com.supereme.tailormanagement.viewmodel.InvoiceViewModel;
import java.util.UUID;

public class AddInvoiceActivity extends AppCompatActivity {
    
    private EditText customerIdInput;
    private EditText orderIdInput;
    private EditText invoiceNumberInput;
    private EditText subtotalInput;
    private EditText taxInput;
    private EditText discountInput;
    private EditText statusInput;
    private Button saveButton;
    private InvoiceViewModel viewModel;
    private Integer invoiceId;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_invoice);
        
        customerIdInput = findViewById(R.id.invoice_customer_id_input);
        orderIdInput = findViewById(R.id.invoice_order_id_input);
        invoiceNumberInput = findViewById(R.id.invoice_number_input);
        subtotalInput = findViewById(R.id.invoice_subtotal_input);
        taxInput = findViewById(R.id.invoice_tax_input);
        discountInput = findViewById(R.id.invoice_discount_input);
        statusInput = findViewById(R.id.invoice_status_input);
        saveButton = findViewById(R.id.btn_save);
        
        viewModel = new ViewModelProvider(this).get(InvoiceViewModel.class);
        
        invoiceId = getIntent().getIntExtra("invoice_id", -1);
        if (invoiceId != -1) {
            setTitle("Edit Invoice");
            loadInvoice(invoiceId);
        } else {
            setTitle("Add Invoice");
            invoiceNumberInput.setText("INV-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        
        saveButton.setOnClickListener(v -> saveInvoice());
    }
    
    private void loadInvoice(int id) {
        viewModel.getInvoiceById(id).observe(this, invoice -> {
            if (invoice != null) {
                customerIdInput.setText(String.valueOf(invoice.customerId));
                orderIdInput.setText(String.valueOf(invoice.orderId));
                invoiceNumberInput.setText(invoice.invoiceNumber);
                subtotalInput.setText(String.valueOf(invoice.subtotal));
                taxInput.setText(String.valueOf(invoice.taxAmount));
                discountInput.setText(String.valueOf(invoice.discountAmount));
                statusInput.setText(invoice.status);
            }
        });
    }
    
    private void saveInvoice() {
        String customerIdStr = customerIdInput.getText().toString().trim();
        String orderIdStr = orderIdInput.getText().toString().trim();
        String invoiceNumber = invoiceNumberInput.getText().toString().trim();
        String subtotalStr = subtotalInput.getText().toString().trim();
        String taxStr = taxInput.getText().toString().trim();
        String discountStr = discountInput.getText().toString().trim();
        String status = statusInput.getText().toString().trim();
        
        if (customerIdStr.isEmpty() || orderIdStr.isEmpty() || invoiceNumber.isEmpty()) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            int customerId = Integer.parseInt(customerIdStr);
            int orderId = Integer.parseInt(orderIdStr);
            double subtotal = Double.parseDouble(subtotalStr.isEmpty() ? "0" : subtotalStr);
            double tax = Double.parseDouble(taxStr.isEmpty() ? "0" : taxStr);
            double discount = Double.parseDouble(discountStr.isEmpty() ? "0" : discountStr);
            
            Invoice invoice = new Invoice(customerId, orderId, invoiceNumber);
            invoice.subtotal = subtotal;
            invoice.taxAmount = tax;
            invoice.discountAmount = discount;
            invoice.status = status.isEmpty() ? "draft" : status;
            invoice.calculateTotal();
            
            if (invoiceId != -1) {
                invoice.id = invoiceId;
                viewModel.updateInvoice(invoice);
                Toast.makeText(this, "Invoice updated", Toast.LENGTH_SHORT).show();
            } else {
                viewModel.insertInvoice(invoice);
                Toast.makeText(this, "Invoice created", Toast.LENGTH_SHORT).show();
            }
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input format", Toast.LENGTH_SHORT).show();
        }
    }
}
