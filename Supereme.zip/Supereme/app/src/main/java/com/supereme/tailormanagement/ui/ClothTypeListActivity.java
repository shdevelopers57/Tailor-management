package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.ClothTypeAdapter;
import com.supereme.tailormanagement.database.entity.ClothType;
import com.supereme.tailormanagement.viewmodel.ClothTypeViewModel;

public class ClothTypeListActivity extends AppCompatActivity implements ClothTypeAdapter.OnClothTypeClickListener {
    
    private RecyclerView recyclerView;
    private Button addButton;
    private ClothTypeAdapter adapter;
    private ClothTypeViewModel viewModel;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cloth_type_list);
        
        setTitle("Cloth Types");
        
        recyclerView = findViewById(R.id.recycler_view);
        addButton = findViewById(R.id.btn_add);
        
        setupRecyclerView();
        setupViewModel();
        
        addButton.setOnClickListener(v -> startActivity(new Intent(this, AddClothTypeActivity.class)));
    }
    
    private void setupRecyclerView() {
        adapter = new ClothTypeAdapter(this, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(ClothTypeViewModel.class);
        viewModel.getAllClothTypes().observe(this, clothTypes -> {
            adapter.setClothTypes(clothTypes);
        });
    }
    
    @Override
    public void onEdit(ClothType clothType) {
        Intent intent = new Intent(this, AddClothTypeActivity.class);
        intent.putExtra("cloth_type_id", clothType.id);
        startActivity(intent);
    }
    
    @Override
    public void onDelete(ClothType clothType) {
        viewModel.deleteClothType(clothType);
        Toast.makeText(this, "Cloth type deleted", Toast.LENGTH_SHORT).show();
    }
}
