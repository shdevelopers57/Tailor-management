package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.PaymentDao;
import com.supereme.tailormanagement.database.entity.Payment;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class PaymentRepository {
    
    private PaymentDao paymentDao;
    private LiveData<List<Payment>> allPayments;
    
    public PaymentRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        paymentDao = db.paymentDao();
        allPayments = paymentDao.getAllPayments();
    }
    
    public void insert(Payment payment) {
        if (payment != null) {
            RepositoryExecutor.execute(() -> paymentDao.insert(payment));
        }
    }
    
    public void update(Payment payment) {
        if (payment != null) {
            RepositoryExecutor.execute(() -> paymentDao.update(payment));
        }
    }
    
    public void delete(Payment payment) {
        if (payment != null) {
            RepositoryExecutor.execute(() -> paymentDao.delete(payment));
        }
    }
    
    public LiveData<List<Payment>> getAllPayments() {
        return allPayments;
    }
    
    public LiveData<Payment> getPaymentById(int id) {
        return paymentDao.getPaymentById(id);
    }
    
    public Payment getPaymentByIdSync(int id) {
        return paymentDao.getPaymentByIdSync(id);
    }
    
    public LiveData<List<Payment>> getPaymentsByCustomerId(int customerId) {
        return paymentDao.getPaymentsByCustomerId(customerId);
    }
    
    public List<Payment> getPaymentsByCustomerIdSync(int customerId) {
        return paymentDao.getPaymentsByCustomerIdSync(customerId);
    }
    
    public LiveData<List<Payment>> getPaymentsByOrderId(int orderId) {
        return paymentDao.getPaymentsByOrderId(orderId);
    }
    
    public List<Payment> getPaymentsByOrderIdSync(int orderId) {
        return paymentDao.getPaymentsByOrderIdSync(orderId);
    }
    
    public LiveData<Double> getTotalPaidByCustomer(int customerId) {
        return paymentDao.getTotalPaidByCustomer(customerId);
    }
    
    public Double getTotalPaidForOrder(int orderId) {
        Double result = paymentDao.getTotalPaidForOrder(orderId);
        return result != null ? result : 0.0;
    }
    
    public LiveData<Double> getTotalPayments() {
        return paymentDao.getTotalPayments();
    }
    
    public LiveData<List<Payment>> getRecentPayments() {
        return paymentDao.getRecentPayments();
    }
}
