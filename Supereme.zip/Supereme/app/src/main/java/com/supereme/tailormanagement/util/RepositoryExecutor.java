package com.supereme.tailormanagement.util;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Utility class for managing background thread execution in repositories.
 * Provides a shared ExecutorService to prevent thread leaks and resource exhaustion.
 */
public class RepositoryExecutor {
    
    private static final int THREAD_POOL_SIZE = 2;
    private static volatile ExecutorService executorService;
    
    private RepositoryExecutor() {
        // Private constructor to prevent instantiation
    }
    
    /**
     * Get the shared ExecutorService instance (lazy initialization).
     * Uses double-check locking for thread-safe singleton pattern.
     */
    public static ExecutorService getExecutorService() {
        if (executorService == null) {
            synchronized (RepositoryExecutor.class) {
                if (executorService == null) {
                    executorService = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
                }
            }
        }
        return executorService;
    }
    
    /**
     * Execute a task asynchronously.
     */
    public static void execute(Runnable task) {
        getExecutorService().execute(task);
    }
    
    /**
     * Shutdown the executor service (call this during app lifecycle termination).
     */
    public static void shutdown() {
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown();
            executorService = null;
        }
    }
}
