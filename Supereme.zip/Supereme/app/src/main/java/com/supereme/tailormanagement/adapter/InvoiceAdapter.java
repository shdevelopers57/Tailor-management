package com.supereme.tailormanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Invoice;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class InvoiceAdapter extends RecyclerView.Adapter<InvoiceAdapter.InvoiceViewHolder> {
    
    private Context context;
    private List<Invoice> invoices;
    private OnInvoiceClickListener listener;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
    
    public interface OnInvoiceClickListener {
        void onView(Invoice invoice);
        void onEdit(Invoice invoice);
        void onDelete(Invoice invoice);
    }
    
    public InvoiceAdapter(Context context, OnInvoiceClickListener listener) {
        this.context = context;
        this.listener = listener;
    }
    
    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public InvoiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_invoice, parent, false);
        return new InvoiceViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull InvoiceViewHolder holder, int position) {
        Invoice invoice = invoices.get(position);
        holder.bind(invoice);
    }
    
    @Override
    public int getItemCount() {
        return invoices == null ? 0 : invoices.size();
    }
    
    public class InvoiceViewHolder extends RecyclerView.ViewHolder {
        private TextView invoiceNumber;
        private TextView invoiceStatus;
        private TextView invoiceAmount;
        private TextView invoiceDate;
        private ImageView viewButton;
        private ImageView editButton;
        private ImageView deleteButton;
        
        public InvoiceViewHolder(@NonNull View itemView) {
            super(itemView);
            invoiceNumber = itemView.findViewById(R.id.invoice_number);
            invoiceStatus = itemView.findViewById(R.id.invoice_status);
            invoiceAmount = itemView.findViewById(R.id.invoice_amount);
            invoiceDate = itemView.findViewById(R.id.invoice_date);
            viewButton = itemView.findViewById(R.id.btn_view);
            editButton = itemView.findViewById(R.id.btn_edit);
            deleteButton = itemView.findViewById(R.id.btn_delete);
        }
        
        public void bind(Invoice invoice) {
            invoiceNumber.setText("Invoice: " + invoice.invoiceNumber);
            invoiceStatus.setText("Status: " + invoice.status);
            invoiceAmount.setText("₹ " + String.format("%.2f", invoice.totalAmount));
            invoiceDate.setText(dateFormat.format(invoice.invoiceDate));
            
            // Color code by status
            String statusColor = getStatusColor(invoice.status);
            invoiceStatus.setTextColor(android.graphics.Color.parseColor(statusColor));
            
            viewButton.setOnClickListener(v -> listener.onView(invoice));
            editButton.setOnClickListener(v -> listener.onEdit(invoice));
            deleteButton.setOnClickListener(v -> listener.onDelete(invoice));
        }
        
        private String getStatusColor(String status) {
            switch (status) {
                case "paid": return "#4CAF50"; // Green
                case "partially_paid": return "#FF9800"; // Orange
                case "pending": return "#2196F3"; // Blue
                case "overdue": return "#F44336"; // Red
                default: return "#666666"; // Gray
            }
        }
    }
}
