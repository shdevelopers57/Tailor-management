package com.supereme.tailormanagement.ui;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.supereme.tailormanagement.R;
import java.io.File;

public class SettingsActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_settings);
            Toolbar toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                setSupportActionBar(toolbar);
            }
            setupButtons();
        } catch (Exception e) {
            Log.e("SettingsActivity", "Error initializing settings", e);
            Toast.makeText(this, "ترتیبات کھولنے میں مسئلہ ہوا", Toast.LENGTH_LONG).show();
        }
    }
    
    private void setupButtons() {
        Button btnClearCache = findViewById(R.id.btn_clear_cache);
        Button btnAppInfo = findViewById(R.id.btn_app_info);
        
        if (btnClearCache != null) {
            btnClearCache.setOnClickListener(v -> clearAppCache());
        }
        
        if (btnAppInfo != null) {
            btnAppInfo.setOnClickListener(v -> showAppInfo());
        }
    }
    
    private void clearAppCache() {
        try {
            File cacheDir = getCacheDir();
            if (cacheDir != null) {
                deleteDir(cacheDir);
            }
            Toast.makeText(this, "کیش صاف ہو گیا", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e("SettingsActivity", "Error clearing cache", e);
            Toast.makeText(this, "کیش صاف نہیں ہو سکی", Toast.LENGTH_SHORT).show();
        }
    }
    
    private boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            if (children != null) {
                for (String child : children) {
                    boolean success = deleteDir(new File(dir, child));
                    if (!success) {
                        return false;
                    }
                }
            }
        }
        return dir.delete();
    }
    
    private void showAppInfo() {
        String appName = getString(R.string.app_name);
        String version = "1.0.0";
        String info = "ایپ کا نام: " + appName + "\nورژن: " + version + "\nاسٹیٹس: برقرار";
        Toast.makeText(this, info, Toast.LENGTH_LONG).show();
    }
}
