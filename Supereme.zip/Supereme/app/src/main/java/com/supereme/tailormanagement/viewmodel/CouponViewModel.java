package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.Coupon;
import com.supereme.tailormanagement.repository.CouponRepository;
import java.util.List;

public class CouponViewModel extends AndroidViewModel {
    
    private CouponRepository repository;
    private LiveData<List<Coupon>> allCoupons;
    
    public CouponViewModel(Application application) {
        super(application);
        repository = new CouponRepository(application);
        allCoupons = repository.getAllCoupons();
    }
    
    public LiveData<List<Coupon>> getAllCoupons() {
        return allCoupons;
    }
    
    public LiveData<Coupon> getCouponById(int id) {
        return repository.getCouponById(id);
    }
    
    public LiveData<List<Coupon>> getActiveCoupons() {
        return repository.getActiveCoupons();
    }
    
    public LiveData<List<Coupon>> searchCoupons(String query) {
        return repository.searchCoupons(query);
    }
    
    public void insertCoupon(Coupon coupon) {
        repository.insert(coupon);
    }
    
    public void updateCoupon(Coupon coupon) {
        repository.update(coupon);
    }
    
    public void deleteCoupon(Coupon coupon) {
        repository.delete(coupon);
    }
}
