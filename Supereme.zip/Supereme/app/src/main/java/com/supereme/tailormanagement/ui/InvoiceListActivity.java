package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.InvoiceAdapter;
import com.supereme.tailormanagement.database.entity.Invoice;
import com.supereme.tailormanagement.viewmodel.InvoiceViewModel;

public class InvoiceListActivity extends AppCompatActivity implements InvoiceAdapter.OnInvoiceClickListener {
    
    private RecyclerView recyclerView;
    private Button addButton;
    private InvoiceAdapter adapter;
    private InvoiceViewModel viewModel;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_list);
        
        setTitle("Invoices");
        
        recyclerView = findViewById(R.id.recycler_view);
        addButton = findViewById(R.id.btn_add);
        
        setupRecyclerView();
        setupViewModel();
        
        addButton.setOnClickListener(v -> startActivity(new Intent(this, AddInvoiceActivity.class)));
    }
    
    private void setupRecyclerView() {
        adapter = new InvoiceAdapter(this, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(InvoiceViewModel.class);
        viewModel.getAllInvoices().observe(this, invoices -> {
            adapter.setInvoices(invoices);
        });
    }
    
    @Override
    public void onView(Invoice invoice) {
        Intent intent = new Intent(this, InvoiceDetailsActivity.class);
        intent.putExtra("invoice_id", invoice.id);
        startActivity(intent);
    }
    
    @Override
    public void onEdit(Invoice invoice) {
        Intent intent = new Intent(this, AddInvoiceActivity.class);
        intent.putExtra("invoice_id", invoice.id);
        startActivity(intent);
    }
    
    @Override
    public void onDelete(Invoice invoice) {
        viewModel.deleteInvoice(invoice);
        Toast.makeText(this, "Invoice deleted", Toast.LENGTH_SHORT).show();
    }
}
