package com.supereme.tailormanagement.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Order;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {
    
    private List<Order> orders = new ArrayList<>();
    private OnOrderClickListener onOrderClickListener;
    
    public interface OnOrderClickListener {
        void onOrderClick(Order order, int position);
    }
    
    public OrderAdapter(OnOrderClickListener onOrderClickListener) {
        this.onOrderClickListener = onOrderClickListener;
    }
    
    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        MaterialCardView cardView = (MaterialCardView) inflater.inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(cardView);
    }
    
    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);
        holder.bind(order, position);
    }
    
    @Override
    public int getItemCount() {
        return orders.size();
    }
    
    public void setOrders(List<Order> orders) {
        this.orders = orders != null ? orders : new ArrayList<>();
        notifyDataSetChanged();
    }
    
    class OrderViewHolder extends RecyclerView.ViewHolder {
        private MaterialCardView cardView;
        private TextView tvOrderId, tvType, tvStatus, tvAmount;
        private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        
        public OrderViewHolder(MaterialCardView cardView) {
            super(cardView);
            this.cardView = cardView;
            
            // Get references from the inflated layout
            tvOrderId = cardView.findViewById(R.id.tv_order_id);
            tvType = cardView.findViewById(R.id.tv_order_type);
            tvStatus = cardView.findViewById(R.id.tv_order_status);
            tvAmount = cardView.findViewById(R.id.tv_order_amount);
            
            cardView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION && onOrderClickListener != null) {
                    onOrderClickListener.onOrderClick(orders.get(position), position);
                }
            });
        }
        
        public void bind(Order order, int position) {
            if (order == null) {
                tvOrderId.setText("آرڈر #-");
                tvType.setText("قسم: نامعلوم");
                tvStatus.setText("زیرالتوا");
                tvAmount.setText("رقم: Rs. 0");
                return;
            }
            tvOrderId.setText("آرڈر #" + order.id);
            tvType.setText("قسم: " + (order.orderType != null ? order.orderType : "نامعلوم"));
            tvStatus.setText(order.status != null ? getUrduStatus(order.status) : "زیرالتوا");
            tvAmount.setText(String.format("رقم: Rs. %.0f", order.amount));
        }
        
        private String getUrduStatus(String status) {
            switch (status.toLowerCase()) {
                case "pending": return "زیرالتوا";
                case "designing": return "ڈیزائن";
                case "tailoring": return "سلائی";
                case "fitting": return "فٹنگ";
                case "completed": return "مکمل";
                case "delivered": return "ڈلیور شدہ";
                case "cancelled": return "منسوخ";
                default: return status;
            }
        }
    }
}
