package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Payment;
import java.util.List;

@Dao
public interface PaymentDao {
    
    @Insert
    long insert(Payment payment);
    
    @Update
    int update(Payment payment);
    
    @Delete
    int delete(Payment payment);
    
    @Query("SELECT * FROM payments WHERE id = :id")
    LiveData<Payment> getPaymentById(int id);
    
    @Query("SELECT * FROM payments WHERE id = :id")
    Payment getPaymentByIdSync(int id);
    
    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY paymentDate DESC")
    LiveData<List<Payment>> getPaymentsByCustomerId(int customerId);
    
    @Query("SELECT * FROM payments WHERE customerId = :customerId ORDER BY paymentDate DESC")
    List<Payment> getPaymentsByCustomerIdSync(int customerId);
    
    @Query("SELECT * FROM payments WHERE orderId = :orderId ORDER BY paymentDate DESC")
    LiveData<List<Payment>> getPaymentsByOrderId(int orderId);
    
    @Query("SELECT * FROM payments WHERE orderId = :orderId ORDER BY paymentDate DESC")
    List<Payment> getPaymentsByOrderIdSync(int orderId);
    
    @Query("SELECT * FROM payments ORDER BY paymentDate DESC")
    LiveData<List<Payment>> getAllPayments();
    
    @Query("SELECT * FROM payments ORDER BY paymentDate DESC")
    List<Payment> getAllPaymentsSync();
    
    @Query("SELECT SUM(amount) FROM payments WHERE customerId = :customerId")
    LiveData<Double> getTotalPaidByCustomer(int customerId);
    
    @Query("SELECT SUM(amount) FROM payments WHERE orderId = :orderId")
    Double getTotalPaidForOrder(int orderId);
    
    @Query("SELECT SUM(amount) FROM payments")
    LiveData<Double> getTotalPayments();
    
    @Query("DELETE FROM payments WHERE id = :id")
    void deleteById(int id);
    
    @Query("SELECT * FROM payments ORDER BY paymentDate DESC LIMIT 10")
    LiveData<List<Payment>> getRecentPayments();
}
