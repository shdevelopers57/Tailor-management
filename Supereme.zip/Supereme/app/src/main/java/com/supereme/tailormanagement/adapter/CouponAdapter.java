package com.supereme.tailormanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Coupon;
import java.util.List;

public class CouponAdapter extends RecyclerView.Adapter<CouponAdapter.CouponViewHolder> {
    
    private Context context;
    private List<Coupon> coupons;
    private OnCouponClickListener listener;
    
    public interface OnCouponClickListener {
        void onEdit(Coupon coupon);
        void onDelete(Coupon coupon);
    }
    
    public CouponAdapter(Context context, OnCouponClickListener listener) {
        this.context = context;
        this.listener = listener;
    }
    
    public void setCoupons(List<Coupon> coupons) {
        this.coupons = coupons;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public CouponViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_coupon, parent, false);
        return new CouponViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull CouponViewHolder holder, int position) {
        if (coupons == null || position >= coupons.size()) return;
        Coupon coupon = coupons.get(position);
        holder.bind(coupon);
    }
    
    @Override
    public int getItemCount() {
        return coupons == null ? 0 : coupons.size();
    }
    
    public class CouponViewHolder extends RecyclerView.ViewHolder {
        private TextView couponCode;
        private TextView couponDiscount;
        private TextView couponUsage;
        private ImageView editButton;
        private ImageView deleteButton;
        
        public CouponViewHolder(@NonNull View itemView) {
            super(itemView);
            couponCode = itemView.findViewById(R.id.coupon_code);
            couponDiscount = itemView.findViewById(R.id.coupon_discount);
            couponUsage = itemView.findViewById(R.id.coupon_usage);
            editButton = itemView.findViewById(R.id.btn_edit);
            deleteButton = itemView.findViewById(R.id.btn_delete);
        }
        
        public void bind(Coupon coupon) {
            if (coupon == null) return;
            couponCode.setText(coupon.code != null ? coupon.code : "");
            String discountType = coupon.discountType != null ? coupon.discountType : "";
            String discountText = coupon.discountValue + 
                    ("percentage".equals(discountType) ? "%" : "");
            couponDiscount.setText("Discount: " + discountText);
            couponUsage.setText("Used: " + coupon.usageCount + 
                    (coupon.usageLimit > 0 ? " / " + coupon.usageLimit : ""));
            
            editButton.setOnClickListener(v -> listener.onEdit(coupon));
            deleteButton.setOnClickListener(v -> listener.onDelete(coupon));
        }
    }
}
