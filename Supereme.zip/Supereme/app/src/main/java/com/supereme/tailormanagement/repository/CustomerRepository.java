package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.CustomerDao;
import com.supereme.tailormanagement.database.entity.Customer;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class CustomerRepository {
    
    private CustomerDao customerDao;
    private LiveData<List<Customer>> allCustomers;
    
    public CustomerRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        customerDao = db.customerDao();
        allCustomers = customerDao.getAllCustomers();
    }
    
    public void insert(Customer customer) {
        if (customer != null) {
            RepositoryExecutor.execute(() -> customerDao.insert(customer));
        }
    }
    
    public void update(Customer customer) {
        if (customer != null) {
            RepositoryExecutor.execute(() -> customerDao.update(customer));
        }
    }
    
    public void delete(Customer customer) {
        if (customer != null) {
            RepositoryExecutor.execute(() -> customerDao.delete(customer));
        }
    }
    
    public LiveData<List<Customer>> getAllCustomers() {
        return allCustomers;
    }
    
    public LiveData<Customer> getCustomerById(int id) {
        return customerDao.getCustomerById(id);
    }
    
    public Customer getCustomerByIdSync(int id) {
        return customerDao.getCustomerByIdSync(id);
    }
    
    public LiveData<List<Customer>> searchCustomers(String query) {
        return customerDao.searchCustomers(query);
    }
    
    public Customer getCustomerByPhone(String phone) {
        if (phone == null || phone.isEmpty()) return null;
        return customerDao.getCustomerByPhone(phone);
    }
    
    public Customer getCustomerByPhoneSync(String phone) {
        if (phone == null || phone.isEmpty()) return null;
        return customerDao.getCustomerByPhone(phone);
    }
    
    public LiveData<Integer> getCustomerCount() {
        return customerDao.getCustomerCount();
    }
    
    public LiveData<List<Customer>> getRecentCustomers() {
        return customerDao.getRecentCustomers();
    }
}
