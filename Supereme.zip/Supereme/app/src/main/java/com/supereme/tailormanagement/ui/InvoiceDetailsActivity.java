package com.supereme.tailormanagement.ui;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.InvoiceItemAdapter;
import com.supereme.tailormanagement.viewmodel.InvoiceViewModel;

public class InvoiceDetailsActivity extends AppCompatActivity {
    
    private TextView invoiceNumber;
    private TextView invoiceStatus;
    private TextView invoiceTotal;
    private RecyclerView itemsRecyclerView;
    private InvoiceItemAdapter adapter;
    private InvoiceViewModel viewModel;
    private int invoiceId;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice_details);
        
        setTitle("Invoice Details");
        
        invoiceNumber = findViewById(R.id.invoice_number_detail);
        invoiceStatus = findViewById(R.id.invoice_status_detail);
        invoiceTotal = findViewById(R.id.invoice_total_detail);
        itemsRecyclerView = findViewById(R.id.items_recycler_view);
        
        viewModel = new ViewModelProvider(this).get(InvoiceViewModel.class);
        invoiceId = getIntent().getIntExtra("invoice_id", -1);
        
        setupItemsRecyclerView();
        loadInvoiceDetails();
    }
    
    private void setupItemsRecyclerView() {
        adapter = new InvoiceItemAdapter(this);
        itemsRecyclerView.setAdapter(adapter);
        itemsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void loadInvoiceDetails() {
        viewModel.getInvoiceById(invoiceId).observe(this, invoice -> {
            if (invoice != null) {
                invoiceNumber.setText("Invoice: " + invoice.invoiceNumber);
                invoiceStatus.setText("Status: " + invoice.status);
                invoiceTotal.setText("Total: ₹" + String.format("%.2f", invoice.totalAmount));
            }
        });
        
        viewModel.getInvoiceItems(invoiceId).observe(this, items -> {
            adapter.setItems(items);
        });
    }
}
