package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Tax;
import java.util.List;

@Dao
public interface TaxDao {
    
    @Insert
    long insert(Tax tax);
    
    @Update
    int update(Tax tax);
    
    @Delete
    int delete(Tax tax);
    
    @Query("SELECT * FROM taxes WHERE id = :id")
    LiveData<Tax> getTaxById(int id);
    
    @Query("SELECT * FROM taxes WHERE id = :id")
    Tax getTaxByIdSync(int id);
    
    @Query("SELECT * FROM taxes WHERE isActive = 1 ORDER BY name ASC")
    LiveData<List<Tax>> getAllTaxes();
    
    @Query("SELECT * FROM taxes WHERE isActive = 1 ORDER BY name ASC")
    List<Tax> getAllTaxesSync();
    
    @Query("SELECT * FROM taxes WHERE name LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY name ASC")
    LiveData<List<Tax>> searchTaxes(String searchQuery);
    
    @Query("SELECT COUNT(*) FROM taxes WHERE isActive = 1")
    LiveData<Integer> getTaxCount();
    
    @Query("DELETE FROM taxes WHERE id = :id")
    void deleteById(int id);
}
