package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.Order;
import com.supereme.tailormanagement.repository.OrderRepository;
import java.util.List;

public class OrderViewModel extends AndroidViewModel {
    
    private final OrderRepository orderRepository;
    
    public OrderViewModel(@NonNull Application application) {
        super(application);
        orderRepository = new OrderRepository(application);
    }
    
    public LiveData<List<Order>> getAllOrders() {
        return orderRepository.getAllOrders();
    }
    
    public LiveData<List<Order>> getOrdersByCustomerId(int customerId) {
        return orderRepository.getOrdersByCustomerId(customerId);
    }
    
    public LiveData<List<Order>> getOrdersByStatus(String status) {
        return orderRepository.getOrdersByStatus(status);
    }
    
    public void insertOrder(Order order) {
        orderRepository.insert(order);
    }
    
    public void updateOrder(Order order) {
        orderRepository.update(order);
    }
    
    public void deleteOrder(Order order) {
        orderRepository.delete(order);
    }
}
