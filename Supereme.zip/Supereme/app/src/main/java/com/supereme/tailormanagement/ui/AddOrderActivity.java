package com.supereme.tailormanagement.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Order;
import com.supereme.tailormanagement.viewmodel.OrderViewModel;

public class AddOrderActivity extends AppCompatActivity {
    
    private OrderViewModel orderViewModel;
    private EditText etOrderAmount, etAdvanceAmount, etDescription;
    private Spinner spOrderType, spOrderStatus;
    private Button btnSave, btnCancel, btnAddMeasurement;
    private int customerId = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_order);
        
        customerId = getIntent().getIntExtra("customer_id", -1);
        orderViewModel = new ViewModelProvider(this).get(OrderViewModel.class);
        
        initializeViews();
        setupClickListeners();
    }
    
    private void initializeViews() {
        etOrderAmount = findViewById(R.id.et_order_amount);
        etAdvanceAmount = findViewById(R.id.et_advance_amount);
        etDescription = findViewById(R.id.et_description);
        spOrderType = findViewById(R.id.sp_order_type);
        spOrderStatus = findViewById(R.id.sp_order_status);
        btnSave = findViewById(R.id.btn_save);
        btnCancel = findViewById(R.id.btn_cancel);
        btnAddMeasurement = findViewById(R.id.btn_add_measurement);
    }
    
    private void setupClickListeners() {
        btnSave.setOnClickListener(v -> saveOrder());
        btnCancel.setOnClickListener(v -> finish());
        btnAddMeasurement.setOnClickListener(v -> addMeasurement());
    }
    
    private void saveOrder() {
        if (customerId == -1) {
            Toast.makeText(this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            Order order = new Order();
            order.customerId = customerId;
            order.orderType = spOrderType.getSelectedItem().toString();
            order.status = spOrderStatus.getSelectedItem().toString();
            order.amount = Double.parseDouble(etOrderAmount.getText().toString());
            order.advance = Double.parseDouble(etAdvanceAmount.getText().toString());
            order.remaining = order.amount - order.advance;
            order.description = etDescription.getText().toString();
            
            orderViewModel.insertOrder(order);
            Toast.makeText(this, R.string.order_added, Toast.LENGTH_SHORT).show();
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.error, Toast.LENGTH_SHORT).show();
        }
    }
    
    private void addMeasurement() {
        // TODO: Navigate to AddMeasurementActivity after order is created
        Toast.makeText(this, R.string.measurement_saved, Toast.LENGTH_SHORT).show();
    }
}
