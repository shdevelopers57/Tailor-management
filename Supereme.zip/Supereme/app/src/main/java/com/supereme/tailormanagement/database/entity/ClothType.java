package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "cloth_types")
public class ClothType {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String name;
    public String description;
    public double defaultPrice;
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public ClothType() {
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Ignore
    public ClothType(String name, String description, double defaultPrice) {
        this.name = name;
        this.description = description;
        this.defaultPrice = defaultPrice;
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Override
    public String toString() {
        return name;
    }
}
