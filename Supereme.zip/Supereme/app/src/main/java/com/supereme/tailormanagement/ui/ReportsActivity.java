package com.supereme.tailormanagement.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.supereme.tailormanagement.R;

public class ReportsActivity extends AppCompatActivity {
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);
    }
}
