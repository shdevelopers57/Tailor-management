package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.Expense;
import com.supereme.tailormanagement.repository.ExpenseRepository;
import java.util.List;

public class ExpenseViewModel extends AndroidViewModel {
    
    private ExpenseRepository repository;
    private LiveData<List<Expense>> allExpenses;
    
    public ExpenseViewModel(Application application) {
        super(application);
        repository = new ExpenseRepository(application);
        allExpenses = repository.getAllExpenses();
    }
    
    public LiveData<List<Expense>> getAllExpenses() {
        return allExpenses;
    }
    
    public LiveData<Expense> getExpenseById(int id) {
        return repository.getExpenseById(id);
    }
    
    public LiveData<List<Expense>> getExpensesByCategory(String category) {
        return repository.getExpensesByCategory(category);
    }
    
    public LiveData<List<Expense>> searchExpenses(String query) {
        return repository.searchExpenses(query);
    }
    
    public LiveData<Double> getTotalExpenses() {
        return repository.getTotalExpenses();
    }
    
    public LiveData<List<String>> getAllCategories() {
        return repository.getAllCategories();
    }
    
    public void insertExpense(Expense expense) {
        repository.insert(expense);
    }
    
    public void updateExpense(Expense expense) {
        repository.update(expense);
    }
    
    public void deleteExpense(Expense expense) {
        repository.delete(expense);
    }
}
