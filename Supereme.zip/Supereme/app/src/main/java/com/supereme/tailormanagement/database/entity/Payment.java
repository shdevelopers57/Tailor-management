package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "payments", foreignKeys = {
        @ForeignKey(entity = Customer.class, parentColumns = "id", childColumns = "customerId", onDelete = ForeignKey.CASCADE),
        @ForeignKey(entity = Order.class, parentColumns = "id", childColumns = "orderId", onDelete = ForeignKey.CASCADE)
},
        indices = {@Index("customerId"), @Index("orderId")})
public class Payment {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public int customerId;
    public int orderId;
    public double amount;
    public Date paymentDate;
    public String paymentMethod; // cash, card, bank_transfer
    public String notes;
    public Date createdDate;
    
    public Payment() {
        this.paymentDate = new Date();
        this.createdDate = new Date();
    }
    
    @Ignore
    public Payment(int customerId, int orderId, double amount, String paymentMethod) {
        this.customerId = customerId;
        this.orderId = orderId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.paymentDate = new Date();
        this.createdDate = new Date();
    }
    
    @Override
    public String toString() {
        return "Payment{" +
                "id=" + id +
                ", amount=" + amount +
                ", paymentMethod='" + paymentMethod + '\'' +
                '}';
    }
}
