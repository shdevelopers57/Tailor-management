package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Measurement;
import com.supereme.tailormanagement.viewmodel.MeasurementViewModel;

public class AddMeasurementActivity extends AppCompatActivity {
    
    private MeasurementViewModel measurementViewModel;
    private EditText etChest, etWaist, etHips, etShoulder, etSleeveLength;
    private EditText etTotalLength, etInseam, etNeckSize, etArmholeDepth;
    private EditText etBackWidth, etFrontWidth, etNotes;
    private Button btnSave, btnCancel;
    private int customerId = -1;
    private int orderId = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_measurement);
        
        // Get ids from intent
        customerId = getIntent().getIntExtra("customer_id", -1);
        orderId = getIntent().getIntExtra("order_id", -1);
        
        measurementViewModel = new ViewModelProvider(this).get(MeasurementViewModel.class);
        
        initializeViews();
        setupClickListeners();
    }
    
    private void initializeViews() {
        etChest = findViewById(R.id.et_chest);
        etWaist = findViewById(R.id.et_waist);
        etHips = findViewById(R.id.et_hips);
        etShoulder = findViewById(R.id.et_shoulder);
        etSleeveLength = findViewById(R.id.et_sleeve_length);
        etTotalLength = findViewById(R.id.et_total_length);
        etInseam = findViewById(R.id.et_inseam);
        etNeckSize = findViewById(R.id.et_neck_size);
        etArmholeDepth = findViewById(R.id.et_armhole_depth);
        etBackWidth = findViewById(R.id.et_back_width);
        etFrontWidth = findViewById(R.id.et_front_width);
        etNotes = findViewById(R.id.et_notes);
        btnSave = findViewById(R.id.btn_save);
        btnCancel = findViewById(R.id.btn_cancel);
    }
    
    private void setupClickListeners() {
        btnSave.setOnClickListener(v -> saveMeasurement());
        btnCancel.setOnClickListener(v -> finish());
    }
    
    private void saveMeasurement() {
        // Validate inputs
        if (customerId == -1) {
            Toast.makeText(this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }
        
        Measurement measurement = new Measurement(customerId, orderId);
        
        // Parse and set measurements
        try {
            if (!etChest.getText().toString().isEmpty()) {
                measurement.chest = Double.parseDouble(etChest.getText().toString());
            }
            if (!etWaist.getText().toString().isEmpty()) {
                measurement.waist = Double.parseDouble(etWaist.getText().toString());
            }
            if (!etHips.getText().toString().isEmpty()) {
                measurement.hips = Double.parseDouble(etHips.getText().toString());
            }
            if (!etShoulder.getText().toString().isEmpty()) {
                measurement.shoulder = Double.parseDouble(etShoulder.getText().toString());
            }
            if (!etSleeveLength.getText().toString().isEmpty()) {
                measurement.sleeveLength = Double.parseDouble(etSleeveLength.getText().toString());
            }
            if (!etTotalLength.getText().toString().isEmpty()) {
                measurement.totalLength = Double.parseDouble(etTotalLength.getText().toString());
            }
            if (!etInseam.getText().toString().isEmpty()) {
                measurement.inseam = Double.parseDouble(etInseam.getText().toString());
            }
            if (!etNeckSize.getText().toString().isEmpty()) {
                measurement.neckSize = Double.parseDouble(etNeckSize.getText().toString());
            }
            if (!etArmholeDepth.getText().toString().isEmpty()) {
                measurement.armholeDepth = Double.parseDouble(etArmholeDepth.getText().toString());
            }
            if (!etBackWidth.getText().toString().isEmpty()) {
                measurement.backWidth = Double.parseDouble(etBackWidth.getText().toString());
            }
            if (!etFrontWidth.getText().toString().isEmpty()) {
                measurement.frontWidth = Double.parseDouble(etFrontWidth.getText().toString());
            }
            measurement.notes = etNotes.getText().toString();
            
            measurementViewModel.insertMeasurement(measurement);
            Toast.makeText(this, R.string.measurement_saved, Toast.LENGTH_SHORT).show();
            
            // Navigate to order summary
            Intent intent = new Intent(AddMeasurementActivity.this, OrderSummaryActivity.class);
            intent.putExtra("customer_id", customerId);
            startActivity(intent);
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.error, Toast.LENGTH_SHORT).show();
        }
    }
}
