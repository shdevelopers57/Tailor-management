package com.supereme.tailormanagement.database;

import android.content.Context;
import android.util.Log;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;
import com.supereme.tailormanagement.database.converter.DateConverter;
import com.supereme.tailormanagement.database.dao.ClothTypeDao;
import com.supereme.tailormanagement.database.dao.CouponDao;
import com.supereme.tailormanagement.database.dao.CustomerDao;
import com.supereme.tailormanagement.database.dao.ExpenseDao;
import com.supereme.tailormanagement.database.dao.InvoiceDao;
import com.supereme.tailormanagement.database.dao.InvoiceItemDao;
import com.supereme.tailormanagement.database.dao.InvoicePaymentDao;
import com.supereme.tailormanagement.database.dao.MeasurementDao;
import com.supereme.tailormanagement.database.dao.MeasurementUnitDao;
import com.supereme.tailormanagement.database.dao.OrderDao;
import com.supereme.tailormanagement.database.dao.PaymentDao;
import com.supereme.tailormanagement.database.dao.TaxDao;
import com.supereme.tailormanagement.database.entity.ClothType;
import com.supereme.tailormanagement.database.entity.Coupon;
import com.supereme.tailormanagement.database.entity.Customer;
import com.supereme.tailormanagement.database.entity.Expense;
import com.supereme.tailormanagement.database.entity.Invoice;
import com.supereme.tailormanagement.database.entity.InvoiceItem;
import com.supereme.tailormanagement.database.entity.InvoicePayment;
import com.supereme.tailormanagement.database.entity.Measurement;
import com.supereme.tailormanagement.database.entity.MeasurementUnit;
import com.supereme.tailormanagement.database.entity.Order;
import com.supereme.tailormanagement.database.entity.Payment;
import com.supereme.tailormanagement.database.entity.Tax;

@Database(entities = {
        Customer.class, Order.class, Measurement.class, Payment.class,
        ClothType.class, MeasurementUnit.class, Expense.class, Tax.class,
        Coupon.class, Invoice.class, InvoiceItem.class, InvoicePayment.class
}, version = 2, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class TailorManagementDatabase extends RoomDatabase {
    
    public abstract CustomerDao customerDao();
    public abstract OrderDao orderDao();
    public abstract MeasurementDao measurementDao();
    public abstract PaymentDao paymentDao();
    public abstract ClothTypeDao clothTypeDao();
    public abstract MeasurementUnitDao measurementUnitDao();
    public abstract ExpenseDao expenseDao();
    public abstract TaxDao taxDao();
    public abstract CouponDao couponDao();
    public abstract InvoiceDao invoiceDao();
    public abstract InvoiceItemDao invoiceItemDao();
    public abstract InvoicePaymentDao invoicePaymentDao();
    
    private static volatile TailorManagementDatabase INSTANCE;
    
    // Migration from version 1 to 2
    public static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            Log.d("Database", "Migrating from version 1 to 2");
            // Add any schema changes here if needed
            // For now, empty migration - schema is compatible
        }
    };
    
    public static TailorManagementDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (TailorManagementDatabase.class) {
                if (INSTANCE == null) {
                    try {
                        INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                TailorManagementDatabase.class, "tailor_management.db")
                                .addMigrations(MIGRATION_1_2)
                                .fallbackToDestructiveMigration() // Fallback for unexpected schema changes
                                .build();
                        Log.d("Database", "Database instance created successfully");
                    } catch (Exception e) {
                        Log.e("Database", "Error creating database instance", e);
                        // Try to recreate by deleting old database
                        try {
                            context.deleteDatabase("tailor_management.db");
                            INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    TailorManagementDatabase.class, "tailor_management.db")
                                    .addMigrations(MIGRATION_1_2)
                                    .fallbackToDestructiveMigration()
                                    .build();
                            Log.d("Database", "Database recreated after deletion");
                        } catch (Exception e2) {
                            Log.e("Database", "Failed to recreate database", e2);
                        }
                    }
                }
            }
        }
        return INSTANCE;
    }
}
