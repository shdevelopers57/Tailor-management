package com.supereme.tailormanagement.ui;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Coupon;
import com.supereme.tailormanagement.viewmodel.CouponViewModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddCouponActivity extends AppCompatActivity {
    
    private EditText codeInput;
    private EditText descriptionInput;
    private EditText discountValueInput;
    private Spinner discountTypeSpinner;
    private EditText validFromInput;
    private EditText validUptoInput;
    private EditText usageLimitInput;
    private Button saveButton;
    private CouponViewModel viewModel;
    private Integer couponId;
    private Date validFromDate;
    private Date validUptoDate;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_coupon);
        
        codeInput = findViewById(R.id.coupon_code_input);
        descriptionInput = findViewById(R.id.coupon_description_input);
        discountValueInput = findViewById(R.id.coupon_discount_value_input);
        discountTypeSpinner = findViewById(R.id.coupon_discount_type_spinner);
        validFromInput = findViewById(R.id.coupon_valid_from_input);
        validUptoInput = findViewById(R.id.coupon_valid_upto_input);
        usageLimitInput = findViewById(R.id.coupon_usage_limit_input);
        saveButton = findViewById(R.id.btn_save);
        
        setupDiscountTypeSpinner();
        
        viewModel = new ViewModelProvider(this).get(CouponViewModel.class);
        
        couponId = getIntent().getIntExtra("coupon_id", -1);
        if (couponId != -1) {
            setTitle("Edit Coupon");
            loadCoupon(couponId);
        } else {
            setTitle("Add Coupon");
        }
        
        validFromInput.setOnClickListener(v -> showDatePickerForValidFrom());
        validUptoInput.setOnClickListener(v -> showDatePickerForValidUpto());
        saveButton.setOnClickListener(v -> saveCoupon());
    }
    
    private void setupDiscountTypeSpinner() {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.discount_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        discountTypeSpinner.setAdapter(adapter);
    }
    
    private void loadCoupon(int id) {
        viewModel.getCouponById(id).observe(this, coupon -> {
            if (coupon != null) {
                codeInput.setText(coupon.code);
                descriptionInput.setText(coupon.description);
                discountValueInput.setText(String.valueOf(coupon.discountValue));
                int typeIndex = "percentage".equals(coupon.discountType) ? 0 : 1;
                discountTypeSpinner.setSelection(typeIndex);
                if (coupon.validFrom != null) {
                    validFromDate = coupon.validFrom;
                    validFromInput.setText(dateFormat.format(validFromDate));
                }
                if (coupon.validUpto != null) {
                    validUptoDate = coupon.validUpto;
                    validUptoInput.setText(dateFormat.format(validUptoDate));
                }
                usageLimitInput.setText(String.valueOf(coupon.usageLimit));
            }
        });
    }
    
    private void showDatePickerForValidFrom() {
        Calendar calendar = Calendar.getInstance();
        if (validFromDate != null) {
            calendar.setTime(validFromDate);
        }
        
        DatePickerDialog datePicker = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(year, month, dayOfMonth);
            validFromDate = calendar.getTime();
            validFromInput.setText(dateFormat.format(validFromDate));
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        
        datePicker.show();
    }
    
    private void showDatePickerForValidUpto() {
        Calendar calendar = Calendar.getInstance();
        if (validUptoDate != null) {
            calendar.setTime(validUptoDate);
        }
        
        DatePickerDialog datePicker = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(year, month, dayOfMonth);
            validUptoDate = calendar.getTime();
            validUptoInput.setText(dateFormat.format(validUptoDate));
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        
        datePicker.show();
    }
    
    private void saveCoupon() {
        String code = codeInput.getText().toString().trim();
        String description = descriptionInput.getText().toString().trim();
        String discountValueStr = discountValueInput.getText().toString().trim();
        String discountType = discountTypeSpinner.getSelectedItem().toString().toLowerCase();
        String usageLimitStr = usageLimitInput.getText().toString().trim();
        
        if (code.isEmpty()) {
            Toast.makeText(this, "Please enter coupon code", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (discountValueStr.isEmpty()) {
            Toast.makeText(this, "Please enter discount value", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            double discountValue = Double.parseDouble(discountValueStr);
            int usageLimit = usageLimitStr.isEmpty() ? 0 : Integer.parseInt(usageLimitStr);
            
            Coupon coupon = new Coupon(code, discountValue, discountType);
            coupon.description = description;
            coupon.validFrom = validFromDate;
            coupon.validUpto = validUptoDate;
            coupon.usageLimit = usageLimit;
            
            if (couponId != -1) {
                coupon.id = couponId;
                viewModel.updateCoupon(coupon);
                Toast.makeText(this, "Coupon updated", Toast.LENGTH_SHORT).show();
            } else {
                viewModel.insertCoupon(coupon);
                Toast.makeText(this, "Coupon created", Toast.LENGTH_SHORT).show();
            }
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input format", Toast.LENGTH_SHORT).show();
        }
    }
}
