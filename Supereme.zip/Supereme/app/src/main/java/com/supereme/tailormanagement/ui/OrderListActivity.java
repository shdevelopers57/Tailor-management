package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.OrderAdapter;
import com.supereme.tailormanagement.database.entity.Order;
import com.supereme.tailormanagement.viewmodel.OrderViewModel;

public class OrderListActivity extends AppCompatActivity {
    
    private OrderViewModel orderViewModel;
    private RecyclerView ordersRecyclerView;
    private FloatingActionButton fabAddOrder;
    private OrderAdapter orderAdapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_order_list);
            
            orderViewModel = new ViewModelProvider(this).get(OrderViewModel.class);
            
            initializeViews();
            setupRecyclerView();
            observeOrders();
            setupFabListener();
        } catch (Exception e) {
            Log.e("OrderListActivity", "Error initializing order list", e);
            Toast.makeText(this, "آرڈرز کی فہرست کھولنے میں مسئلہ ہوا", Toast.LENGTH_LONG).show();
        }
    }
    
    private void initializeViews() {
        ordersRecyclerView = findViewById(R.id.recycler_orders);
        fabAddOrder = findViewById(R.id.fab_add_order);
    }
    
    private void setupRecyclerView() {
        if (ordersRecyclerView == null) return;
        ordersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        orderAdapter = new OrderAdapter(this::onOrderClick);
        ordersRecyclerView.setAdapter(orderAdapter);
    }
    
    private void observeOrders() {
        if (orderViewModel == null || orderAdapter == null) return;
        orderViewModel.getAllOrders().observe(this, orders -> {
            if (orders != null) {
                orderAdapter.setOrders(orders);
            } else {
                orderAdapter.setOrders(new java.util.ArrayList<>());
            }
        });
    }
    
    private void setupFabListener() {
        if (fabAddOrder == null) return;
        fabAddOrder.setOnClickListener(v -> {
            Intent intent = new Intent(OrderListActivity.this, AddOrderActivity.class);
            startActivity(intent);
        });
    }
    
    private void onOrderClick(Order order, int position) {
        // TODO: Handle order click - open order details
    }
}
