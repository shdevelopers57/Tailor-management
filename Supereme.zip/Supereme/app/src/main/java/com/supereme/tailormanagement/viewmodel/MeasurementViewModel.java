package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.Measurement;
import com.supereme.tailormanagement.repository.MeasurementRepository;
import java.util.List;

public class MeasurementViewModel extends AndroidViewModel {
    
    private final MeasurementRepository measurementRepository;
    
    public MeasurementViewModel(@NonNull Application application) {
        super(application);
        measurementRepository = new MeasurementRepository(application);
    }
    
    public LiveData<List<Measurement>> getMeasurementsByCustomerId(int customerId) {
        return measurementRepository.getMeasurementsByCustomerId(customerId);
    }
    
    public LiveData<Measurement> getMeasurementByOrderId(int orderId) {
        return measurementRepository.getMeasurementByOrderId(orderId);
    }
    
    public LiveData<Measurement> getLatestMeasurementForCustomer(int customerId) {
        return measurementRepository.getLatestMeasurementForCustomer(customerId);
    }
    
    public void insertMeasurement(Measurement measurement) {
        measurementRepository.insert(measurement);
    }
    
    public void updateMeasurement(Measurement measurement) {
        measurementRepository.update(measurement);
    }
    
    public void deleteMeasurement(Measurement measurement) {
        measurementRepository.delete(measurement);
    }
}
