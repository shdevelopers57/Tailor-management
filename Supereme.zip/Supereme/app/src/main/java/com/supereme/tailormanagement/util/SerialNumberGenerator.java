package com.supereme.tailormanagement.util;

import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Utility class for generating unique serial numbers for orders/tickets
 */
public class SerialNumberGenerator {
    
    private static final SecureRandom RANDOM = new SecureRandom();
    
    /**
     * Generates a unique serial number in the format: YYYYMMDD-XXXXX-CID
     * Example: 20260619-47292-001
     */
    public static String generateSerialNumber(int customerId) {
        // Date component: YYYYMMDD
        String dateComponent = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());
        
        // Random component: 5 digits (using SecureRandom for better randomness)
        int randomComponent = RANDOM.nextInt(100000);
        String randomPart = String.format("%05d", randomComponent);
        
        // Customer ID component: 3 digits (padded)
        String customerIdPart = String.format("%03d", customerId % 1000);
        
        return dateComponent + "-" + randomPart + "-" + customerIdPart;
    }
    
    /**
     * Alternative format: Compact format
     * Example: S20260619001001
     */
    public static String generateCompactSerialNumber(int customerId) {
        String dateComponent = new SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(new Date());
        String customerIdPart = String.format("%03d", customerId % 1000);
        int randomComponent = RANDOM.nextInt(1000);
        String randomPart = String.format("%03d", randomComponent);
        
        return "S" + dateComponent + customerIdPart + randomPart;
    }
}
