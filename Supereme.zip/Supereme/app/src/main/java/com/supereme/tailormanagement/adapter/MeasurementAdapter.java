package com.supereme.tailormanagement.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Measurement;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class MeasurementAdapter extends RecyclerView.Adapter<MeasurementAdapter.MeasurementViewHolder> {
    
    private List<Measurement> measurements = new ArrayList<>();
    private OnMeasurementClickListener onMeasurementClickListener;
    
    public interface OnMeasurementClickListener {
        void onMeasurementClick(Measurement measurement, int position);
    }
    
    public MeasurementAdapter(OnMeasurementClickListener onMeasurementClickListener) {
        this.onMeasurementClickListener = onMeasurementClickListener;
    }
    
    @NonNull
    @Override
    public MeasurementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        MaterialCardView cardView = (MaterialCardView) inflater.inflate(R.layout.item_measurement, parent, false);
        return new MeasurementViewHolder(cardView);
    }
    
    @Override
    public void onBindViewHolder(@NonNull MeasurementViewHolder holder, int position) {
        Measurement measurement = measurements.get(position);
        holder.bind(measurement, position);
    }
    
    @Override
    public int getItemCount() {
        return measurements.size();
    }
    
    public void setMeasurements(List<Measurement> measurements) {
        this.measurements = measurements != null ? measurements : new ArrayList<>();
        notifyDataSetChanged();
    }
    
    class MeasurementViewHolder extends RecyclerView.ViewHolder {
        private MaterialCardView cardView;
        private TextView tvChest, tvWaist, tvHips, tvShoulder, tvNotes;
        
        public MeasurementViewHolder(MaterialCardView cardView) {
            super(cardView);
            this.cardView = cardView;
            
            // Get references from the inflated layout
            tvChest = cardView.findViewById(R.id.tv_chest);
            tvWaist = cardView.findViewById(R.id.tv_waist);
            tvHips = cardView.findViewById(R.id.tv_hips);
            tvShoulder = cardView.findViewById(R.id.tv_shoulder);
            tvNotes = cardView.findViewById(R.id.tv_notes);
        }
        
        public void bind(Measurement measurement, int position) {
            if (measurement == null) {
                tvChest.setText("سینہ: - سم");
                tvWaist.setText("کمر: - سم");
                tvHips.setText("کولہے: - سم");
                tvShoulder.setText("کندھا: - سم");
                tvNotes.setText("نوٹس: کوئی نہیں");
                return;
            }
            tvChest.setText(String.format("سینہ: %.1f سم", measurement.chest));
            tvWaist.setText(String.format("کمر: %.1f سم", measurement.waist));
            tvHips.setText(String.format("کولہے: %.1f سم", measurement.hips));
            tvShoulder.setText(String.format("کندھا: %.1f سم", measurement.shoulder));
            tvNotes.setText("نوٹس: " + (measurement.notes != null ? measurement.notes : "کوئی نہیں"));
            
            cardView.setOnClickListener(v -> {
                if (onMeasurementClickListener != null) {
                    onMeasurementClickListener.onMeasurementClick(measurement, position);
                }
            });
        }
    }
}
