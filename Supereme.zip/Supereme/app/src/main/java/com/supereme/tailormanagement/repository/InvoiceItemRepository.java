package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.InvoiceItemDao;
import com.supereme.tailormanagement.database.entity.InvoiceItem;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class InvoiceItemRepository {
    
    private InvoiceItemDao invoiceItemDao;
    
    public InvoiceItemRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        invoiceItemDao = db.invoiceItemDao();
    }
    
    public void insert(InvoiceItem item) {
        if (item != null) {
            RepositoryExecutor.execute(() -> invoiceItemDao.insert(item));
        }
    }
    
    public void update(InvoiceItem item) {
        if (item != null) {
            RepositoryExecutor.execute(() -> invoiceItemDao.update(item));
        }
    }
    
    public void delete(InvoiceItem item) {
        if (item != null) {
            RepositoryExecutor.execute(() -> invoiceItemDao.delete(item));
        }
    }
    
    public LiveData<InvoiceItem> getItemById(int id) {
        return invoiceItemDao.getItemById(id);
    }
    
    public InvoiceItem getItemByIdSync(int id) {
        return invoiceItemDao.getItemByIdSync(id);
    }
    
    public LiveData<List<InvoiceItem>> getItemsByInvoice(int invoiceId) {
        return invoiceItemDao.getItemsByInvoice(invoiceId);
    }
    
    public List<InvoiceItem> getItemsByInvoiceSync(int invoiceId) {
        return invoiceItemDao.getItemsByInvoiceSync(invoiceId);
    }
    
    public Double getTotalAmountByInvoice(int invoiceId) {
        Double result = invoiceItemDao.getTotalAmountByInvoice(invoiceId);
        return result != null ? result : 0.0;
    }
}
