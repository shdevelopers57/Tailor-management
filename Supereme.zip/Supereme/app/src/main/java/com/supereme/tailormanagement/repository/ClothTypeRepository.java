package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.ClothTypeDao;
import com.supereme.tailormanagement.database.entity.ClothType;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class ClothTypeRepository {
    
    private ClothTypeDao clothTypeDao;
    private LiveData<List<ClothType>> allClothTypes;
    
    public ClothTypeRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        clothTypeDao = db.clothTypeDao();
        allClothTypes = clothTypeDao.getAllClothTypes();
    }
    
    public void insert(ClothType clothType) {
        if (clothType != null) {
            RepositoryExecutor.execute(() -> clothTypeDao.insert(clothType));
        }
    }
    
    public void update(ClothType clothType) {
        if (clothType != null) {
            RepositoryExecutor.execute(() -> clothTypeDao.update(clothType));
        }
    }
    
    public void delete(ClothType clothType) {
        if (clothType != null) {
            RepositoryExecutor.execute(() -> clothTypeDao.delete(clothType));
        }
    }
    
    public LiveData<List<ClothType>> getAllClothTypes() {
        return allClothTypes;
    }
    
    public LiveData<ClothType> getClothTypeById(int id) {
        return clothTypeDao.getClothTypeById(id);
    }
    
    public ClothType getClothTypeByIdSync(int id) {
        return clothTypeDao.getClothTypeByIdSync(id);
    }
    
    public LiveData<List<ClothType>> searchClothTypes(String query) {
        return clothTypeDao.searchClothTypes(query);
    }
    
    public LiveData<Integer> getClothTypeCount() {
        return clothTypeDao.getClothTypeCount();
    }
    
    public List<ClothType> getAllClothTypesSync() {
        return clothTypeDao.getAllClothTypesSync();
    }
}
