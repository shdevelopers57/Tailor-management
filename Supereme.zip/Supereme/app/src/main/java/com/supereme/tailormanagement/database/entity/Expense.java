package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "expenses")
public class Expense {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String title;
    public String description;
    public double amount;
    public String category; // Rent, Utilities, Materials, Labor, etc.
    public Date expenseDate;
    public String paymentMethod; // Cash, Card, Bank Transfer, Check
    public String reference;
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public Expense() {
        this.expenseDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Ignore
    public Expense(String title, double amount, String category) {
        this.title = title;
        this.amount = amount;
        this.category = category;
        this.expenseDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Override
    public String toString() {
        return "Expense{" +
                "title='" + title + '\'' +
                ", amount=" + amount +
                '}';
    }
}
