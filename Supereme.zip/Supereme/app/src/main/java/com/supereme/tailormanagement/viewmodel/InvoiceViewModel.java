package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.Invoice;
import com.supereme.tailormanagement.database.entity.InvoiceItem;
import com.supereme.tailormanagement.repository.InvoiceItemRepository;
import com.supereme.tailormanagement.repository.InvoiceRepository;
import java.util.List;

public class InvoiceViewModel extends AndroidViewModel {
    
    private InvoiceRepository invoiceRepository;
    private InvoiceItemRepository itemRepository;
    private LiveData<List<Invoice>> allInvoices;
    
    public InvoiceViewModel(Application application) {
        super(application);
        invoiceRepository = new InvoiceRepository(application);
        itemRepository = new InvoiceItemRepository(application);
        allInvoices = invoiceRepository.getAllInvoices();
    }
    
    public LiveData<List<Invoice>> getAllInvoices() {
        return allInvoices;
    }
    
    public LiveData<Invoice> getInvoiceById(int id) {
        return invoiceRepository.getInvoiceById(id);
    }
    
    public LiveData<List<Invoice>> getInvoicesByCustomer(int customerId) {
        return invoiceRepository.getInvoicesByCustomer(customerId);
    }
    
    public LiveData<List<Invoice>> getInvoicesByStatus(String status) {
        return invoiceRepository.getInvoicesByStatus(status);
    }
    
    public LiveData<List<Invoice>> searchInvoices(String query) {
        return invoiceRepository.searchInvoices(query);
    }
    
    public LiveData<List<InvoiceItem>> getInvoiceItems(int invoiceId) {
        return itemRepository.getItemsByInvoice(invoiceId);
    }
    
    public LiveData<Double> getTotalInvoiceAmount() {
        return invoiceRepository.getTotalInvoiceAmount();
    }
    
    public LiveData<Double> getTotalPaidAmount() {
        return invoiceRepository.getTotalPaidAmount();
    }
    
    public void insertInvoice(Invoice invoice) {
        invoiceRepository.insert(invoice);
    }
    
    public void updateInvoice(Invoice invoice) {
        invoiceRepository.update(invoice);
    }
    
    public void deleteInvoice(Invoice invoice) {
        invoiceRepository.delete(invoice);
    }
    
    public void insertInvoiceItem(InvoiceItem item) {
        itemRepository.insert(item);
    }
    
    public void updateInvoiceItem(InvoiceItem item) {
        itemRepository.update(item);
    }
    
    public void deleteInvoiceItem(InvoiceItem item) {
        itemRepository.delete(item);
    }
}
