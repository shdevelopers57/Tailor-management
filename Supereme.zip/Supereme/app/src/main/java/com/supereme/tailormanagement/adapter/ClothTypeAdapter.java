package com.supereme.tailormanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.ClothType;
import java.util.List;

public class ClothTypeAdapter extends RecyclerView.Adapter<ClothTypeAdapter.ClothTypeViewHolder> {
    
    private Context context;
    private List<ClothType> clothTypes;
    private OnClothTypeClickListener listener;
    
    public interface OnClothTypeClickListener {
        void onEdit(ClothType clothType);
        void onDelete(ClothType clothType);
    }
    
    public ClothTypeAdapter(Context context, OnClothTypeClickListener listener) {
        this.context = context;
        this.listener = listener;
    }
    
    public void setClothTypes(List<ClothType> clothTypes) {
        this.clothTypes = clothTypes;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public ClothTypeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cloth_type, parent, false);
        return new ClothTypeViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ClothTypeViewHolder holder, int position) {
        ClothType clothType = clothTypes.get(position);
        holder.bind(clothType);
    }
    
    @Override
    public int getItemCount() {
        return clothTypes == null ? 0 : clothTypes.size();
    }
    
    public class ClothTypeViewHolder extends RecyclerView.ViewHolder {
        private TextView clothTypeName;
        private TextView clothTypePrice;
        private ImageView editButton;
        private ImageView deleteButton;
        
        public ClothTypeViewHolder(@NonNull View itemView) {
            super(itemView);
            clothTypeName = itemView.findViewById(R.id.cloth_type_name);
            clothTypePrice = itemView.findViewById(R.id.cloth_type_price);
            editButton = itemView.findViewById(R.id.btn_edit);
            deleteButton = itemView.findViewById(R.id.btn_delete);
        }
        
        public void bind(ClothType clothType) {
            clothTypeName.setText(clothType.name);
            clothTypePrice.setText("Price: " + clothType.defaultPrice);
            
            editButton.setOnClickListener(v -> listener.onEdit(clothType));
            deleteButton.setOnClickListener(v -> listener.onDelete(clothType));
        }
    }
}
