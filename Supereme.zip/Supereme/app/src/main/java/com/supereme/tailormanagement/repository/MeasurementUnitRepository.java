package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.MeasurementUnitDao;
import com.supereme.tailormanagement.database.entity.MeasurementUnit;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class MeasurementUnitRepository {
    
    private MeasurementUnitDao measurementUnitDao;
    private LiveData<List<MeasurementUnit>> allUnits;
    
    public MeasurementUnitRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        measurementUnitDao = db.measurementUnitDao();
        allUnits = measurementUnitDao.getAllUnits();
    }
    
    public void insert(MeasurementUnit unit) {
        if (unit != null) {
            RepositoryExecutor.execute(() -> measurementUnitDao.insert(unit));
        }
    }
    
    public void update(MeasurementUnit unit) {
        if (unit != null) {
            RepositoryExecutor.execute(() -> measurementUnitDao.update(unit));
        }
    }
    
    public void delete(MeasurementUnit unit) {
        if (unit != null) {
            RepositoryExecutor.execute(() -> measurementUnitDao.delete(unit));
        }
    }
    
    public LiveData<List<MeasurementUnit>> getAllUnits() {
        return allUnits;
    }
    
    public LiveData<MeasurementUnit> getUnitById(int id) {
        return measurementUnitDao.getUnitById(id);
    }
    
    public MeasurementUnit getUnitByIdSync(int id) {
        return measurementUnitDao.getUnitByIdSync(id);
    }
    
    public LiveData<List<MeasurementUnit>> searchUnits(String query) {
        return measurementUnitDao.searchUnits(query);
    }
    
    public LiveData<Integer> getUnitCount() {
        return measurementUnitDao.getUnitCount();
    }
    
    public List<MeasurementUnit> getAllUnitsSync() {
        return measurementUnitDao.getAllUnitsSync();
    }
}
