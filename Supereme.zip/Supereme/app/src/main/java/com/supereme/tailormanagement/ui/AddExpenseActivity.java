package com.supereme.tailormanagement.ui;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Expense;
import com.supereme.tailormanagement.viewmodel.ExpenseViewModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddExpenseActivity extends AppCompatActivity {
    
    private EditText titleInput;
    private EditText descriptionInput;
    private EditText amountInput;
    private Spinner categorySpinner;
    private EditText dateInput;
    private Spinner paymentMethodSpinner;
    private Button saveButton;
    private ExpenseViewModel viewModel;
    private Integer expenseId;
    private Date selectedDate;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);
        
        titleInput = findViewById(R.id.expense_title_input);
        descriptionInput = findViewById(R.id.expense_description_input);
        amountInput = findViewById(R.id.expense_amount_input);
        categorySpinner = findViewById(R.id.expense_category_spinner);
        dateInput = findViewById(R.id.expense_date_input);
        paymentMethodSpinner = findViewById(R.id.expense_payment_method_spinner);
        saveButton = findViewById(R.id.btn_save);
        
        viewModel = new ViewModelProvider(this).get(ExpenseViewModel.class);
        
        expenseId = getIntent().getIntExtra("expense_id", -1);
        if (expenseId != -1) {
            setTitle("Edit Expense");
            loadExpense(expenseId);
        } else {
            setTitle("Add Expense");
            selectedDate = new Date();
            updateDateDisplay();
        }
        
        dateInput.setOnClickListener(v -> showDatePicker());
        saveButton.setOnClickListener(v -> saveExpense());
    }
    
    private void loadExpense(int id) {
        viewModel.getExpenseById(id).observe(this, expense -> {
            if (expense != null) {
                titleInput.setText(expense.title);
                descriptionInput.setText(expense.description);
                amountInput.setText(String.valueOf(expense.amount));
                selectedDate = expense.expenseDate;
                updateDateDisplay();
            }
        });
    }
    
    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        if (selectedDate != null) {
            calendar.setTime(selectedDate);
        }
        
        DatePickerDialog datePicker = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            calendar.set(year, month, dayOfMonth);
            selectedDate = calendar.getTime();
            updateDateDisplay();
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        
        datePicker.show();
    }
    
    private void updateDateDisplay() {
        dateInput.setText(dateFormat.format(selectedDate));
    }
    
    private void saveExpense() {
        String title = titleInput.getText().toString().trim();
        String description = descriptionInput.getText().toString().trim();
        String amountStr = amountInput.getText().toString().trim();
        String category = categorySpinner.getSelectedItem().toString();
        String paymentMethod = paymentMethodSpinner.getSelectedItem().toString();
        
        if (title.isEmpty()) {
            Toast.makeText(this, "Please enter expense title", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (amountStr.isEmpty()) {
            Toast.makeText(this, "Please enter amount", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            double amount = Double.parseDouble(amountStr);
            
            Expense expense = new Expense(title, amount, category);
            expense.description = description;
            expense.expenseDate = selectedDate;
            expense.paymentMethod = paymentMethod;
            
            if (expenseId != -1) {
                expense.id = expenseId;
                viewModel.updateExpense(expense);
                Toast.makeText(this, "Expense updated", Toast.LENGTH_SHORT).show();
            } else {
                viewModel.insertExpense(expense);
                Toast.makeText(this, "Expense added", Toast.LENGTH_SHORT).show();
            }
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid amount format", Toast.LENGTH_SHORT).show();
        }
    }
}
