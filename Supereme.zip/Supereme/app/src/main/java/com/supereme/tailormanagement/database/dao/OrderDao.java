package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Order;
import java.util.List;

@Dao
public interface OrderDao {
    
    @Insert
    long insert(Order order);
    
    @Update
    int update(Order order);
    
    @Delete
    int delete(Order order);
    
    @Query("SELECT * FROM orders WHERE id = :id")
    LiveData<Order> getOrderById(int id);
    
    @Query("SELECT * FROM orders WHERE id = :id")
    Order getOrderByIdSync(int id);
    
    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY orderDate DESC")
    LiveData<List<Order>> getOrdersByCustomerId(int customerId);
    
    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY orderDate DESC")
    List<Order> getOrdersByCustomerIdSync(int customerId);
    
    @Query("SELECT * FROM orders ORDER BY orderDate DESC")
    LiveData<List<Order>> getAllOrders();
    
    @Query("SELECT * FROM orders ORDER BY orderDate DESC")
    List<Order> getAllOrdersSync();
    
    @Query("SELECT * FROM orders WHERE status = :status ORDER BY orderDate DESC")
    LiveData<List<Order>> getOrdersByStatus(String status);
    
    @Query("SELECT * FROM orders WHERE status = :status ORDER BY orderDate DESC")
    List<Order> getOrdersByStatusSync(String status);
    
    @Query("SELECT COUNT(*) FROM orders WHERE status = :status")
    LiveData<Integer> getOrderCountByStatus(String status);
    
    @Query("SELECT SUM(amount) FROM orders WHERE status IN ('completed', 'delivered')")
    LiveData<Double> getTotalCompletedAmount();
    
    @Query("SELECT SUM(remaining) FROM orders WHERE status NOT IN ('completed', 'delivered', 'cancelled')")
    Double getTotalPendingAmount();
    
    @Query("DELETE FROM orders WHERE id = :id")
    void deleteById(int id);
    
    @Query("SELECT * FROM orders ORDER BY orderDate DESC LIMIT 10")
    LiveData<List<Order>> getRecentOrders();
}
