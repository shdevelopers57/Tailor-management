package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.ClothType;
import java.util.List;

@Dao
public interface ClothTypeDao {
    
    @Insert
    long insert(ClothType clothType);
    
    @Update
    int update(ClothType clothType);
    
    @Delete
    int delete(ClothType clothType);
    
    @Query("SELECT * FROM cloth_types WHERE id = :id")
    LiveData<ClothType> getClothTypeById(int id);
    
    @Query("SELECT * FROM cloth_types WHERE id = :id")
    ClothType getClothTypeByIdSync(int id);
    
    @Query("SELECT * FROM cloth_types WHERE isActive = 1 ORDER BY name ASC")
    LiveData<List<ClothType>> getAllClothTypes();
    
    @Query("SELECT * FROM cloth_types WHERE isActive = 1 ORDER BY name ASC")
    List<ClothType> getAllClothTypesSync();
    
    @Query("SELECT * FROM cloth_types WHERE name LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY name ASC")
    LiveData<List<ClothType>> searchClothTypes(String searchQuery);
    
    @Query("SELECT COUNT(*) FROM cloth_types WHERE isActive = 1")
    LiveData<Integer> getClothTypeCount();
    
    @Query("DELETE FROM cloth_types WHERE id = :id")
    void deleteById(int id);
}
