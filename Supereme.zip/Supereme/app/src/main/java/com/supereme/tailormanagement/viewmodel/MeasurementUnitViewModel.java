package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.MeasurementUnit;
import com.supereme.tailormanagement.repository.MeasurementUnitRepository;
import java.util.List;

public class MeasurementUnitViewModel extends AndroidViewModel {
    
    private MeasurementUnitRepository repository;
    private LiveData<List<MeasurementUnit>> allUnits;
    
    public MeasurementUnitViewModel(Application application) {
        super(application);
        repository = new MeasurementUnitRepository(application);
        allUnits = repository.getAllUnits();
    }
    
    public LiveData<List<MeasurementUnit>> getAllUnits() {
        return allUnits;
    }
    
    public LiveData<MeasurementUnit> getUnitById(int id) {
        return repository.getUnitById(id);
    }
    
    public LiveData<List<MeasurementUnit>> searchUnits(String query) {
        return repository.searchUnits(query);
    }
    
    public void insertUnit(MeasurementUnit unit) {
        repository.insert(unit);
    }
    
    public void updateUnit(MeasurementUnit unit) {
        repository.update(unit);
    }
    
    public void deleteUnit(MeasurementUnit unit) {
        repository.delete(unit);
    }
}
