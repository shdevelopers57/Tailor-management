package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import android.util.Log;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import com.supereme.tailormanagement.repository.CustomerRepository;
import com.supereme.tailormanagement.repository.OrderRepository;
import com.supereme.tailormanagement.repository.PaymentRepository;

public class MainViewModel extends AndroidViewModel {
    
    private static final String TAG = "MainViewModel";
    private CustomerRepository customerRepository;
    private OrderRepository orderRepository;
    private PaymentRepository paymentRepository;
    private LiveData<Integer> customerCount;
    private LiveData<Integer> pendingOrderCount;
    private LiveData<Integer> completedOrderCount;
    private LiveData<Double> totalCompletedAmount;
    private LiveData<Double> totalPayments;
    
    public MainViewModel(Application application) {
        super(application);
        try {
            customerRepository = new CustomerRepository(application);
            orderRepository = new OrderRepository(application);
            paymentRepository = new PaymentRepository(application);
            
            // Initialize with safe defaults
            customerCount = customerRepository.getCustomerCount();
            if (customerCount == null) {
                customerCount = new MutableLiveData<>(0);
            }
            
            pendingOrderCount = orderRepository.getOrderCountByStatus("pending");
            if (pendingOrderCount == null) {
                pendingOrderCount = new MutableLiveData<>(0);
            }
            
            completedOrderCount = orderRepository.getOrderCountByStatus("completed");
            if (completedOrderCount == null) {
                completedOrderCount = new MutableLiveData<>(0);
            }
            
            totalCompletedAmount = orderRepository.getTotalCompletedAmount();
            if (totalCompletedAmount == null) {
                totalCompletedAmount = new MutableLiveData<>(0.0);
            }
            
            totalPayments = paymentRepository.getTotalPayments();
            if (totalPayments == null) {
                totalPayments = new MutableLiveData<>(0.0);
            }
            
            Log.d(TAG, "MainViewModel initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "Error initializing repositories", e);
            // Set safe defaults in case of error
            customerCount = new MutableLiveData<>(0);
            pendingOrderCount = new MutableLiveData<>(0);
            completedOrderCount = new MutableLiveData<>(0);
            totalCompletedAmount = new MutableLiveData<>(0.0);
            totalPayments = new MutableLiveData<>(0.0);
        }
    }
    
    public LiveData<Integer> getCustomerCount() {
        return customerCount != null ? customerCount : new MutableLiveData<>(0);
    }
    
    public LiveData<Integer> getPendingOrderCount() {
        return pendingOrderCount != null ? pendingOrderCount : new MutableLiveData<>(0);
    }
    
    public LiveData<Integer> getCompletedOrderCount() {
        return completedOrderCount != null ? completedOrderCount : new MutableLiveData<>(0);
    }
    
    public LiveData<Double> getTotalCompletedAmount() {
        return totalCompletedAmount != null ? totalCompletedAmount : new MutableLiveData<>(0.0);
    }
    
    public LiveData<Double> getTotalPayments() {
        return totalPayments != null ? totalPayments : new MutableLiveData<>(0.0);
    }
}
