package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.InvoiceItem;
import java.util.List;

@Dao
public interface InvoiceItemDao {
    
    @Insert
    long insert(InvoiceItem item);
    
    @Update
    int update(InvoiceItem item);
    
    @Delete
    int delete(InvoiceItem item);
    
    @Query("SELECT * FROM invoice_items WHERE id = :id")
    LiveData<InvoiceItem> getItemById(int id);
    
    @Query("SELECT * FROM invoice_items WHERE id = :id")
    InvoiceItem getItemByIdSync(int id);
    
    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId ORDER BY id ASC")
    LiveData<List<InvoiceItem>> getItemsByInvoice(int invoiceId);
    
    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId ORDER BY id ASC")
    List<InvoiceItem> getItemsByInvoiceSync(int invoiceId);
    
    @Query("SELECT SUM(amount) FROM invoice_items WHERE invoiceId = :invoiceId")
    Double getTotalAmountByInvoice(int invoiceId);
    
    @Query("DELETE FROM invoice_items WHERE invoiceId = :invoiceId")
    void deleteByInvoiceId(int invoiceId);
    
    @Query("DELETE FROM invoice_items WHERE id = :id")
    void deleteById(int id);
}
