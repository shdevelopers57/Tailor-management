package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.CouponAdapter;
import com.supereme.tailormanagement.database.entity.Coupon;
import com.supereme.tailormanagement.viewmodel.CouponViewModel;

public class CouponListActivity extends AppCompatActivity implements CouponAdapter.OnCouponClickListener {
    
    private RecyclerView recyclerView;
    private Button addButton;
    private CouponAdapter adapter;
    private CouponViewModel viewModel;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coupon_list);
        
        setTitle("Coupons & Discounts");
        
        recyclerView = findViewById(R.id.recycler_view);
        addButton = findViewById(R.id.btn_add);
        
        setupRecyclerView();
        setupViewModel();
        
        addButton.setOnClickListener(v -> startActivity(new Intent(this, AddCouponActivity.class)));
    }
    
    private void setupRecyclerView() {
        adapter = new CouponAdapter(this, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(CouponViewModel.class);
        viewModel.getAllCoupons().observe(this, coupons -> {
            adapter.setCoupons(coupons);
        });
    }
    
    @Override
    public void onEdit(Coupon coupon) {
        Intent intent = new Intent(this, AddCouponActivity.class);
        intent.putExtra("coupon_id", coupon.id);
        startActivity(intent);
    }
    
    @Override
    public void onDelete(Coupon coupon) {
        viewModel.deleteCoupon(coupon);
        Toast.makeText(this, "Coupon deleted", Toast.LENGTH_SHORT).show();
    }
}
