package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.InvoicePayment;
import java.util.List;

@Dao
public interface InvoicePaymentDao {
    
    @Insert
    long insert(InvoicePayment payment);
    
    @Update
    int update(InvoicePayment payment);
    
    @Delete
    int delete(InvoicePayment payment);
    
    @Query("SELECT * FROM invoice_payments WHERE id = :id")
    LiveData<InvoicePayment> getPaymentById(int id);
    
    @Query("SELECT * FROM invoice_payments WHERE id = :id")
    InvoicePayment getPaymentByIdSync(int id);
    
    @Query("SELECT * FROM invoice_payments WHERE invoiceId = :invoiceId ORDER BY paymentDate DESC")
    LiveData<List<InvoicePayment>> getPaymentsByInvoice(int invoiceId);
    
    @Query("SELECT * FROM invoice_payments WHERE invoiceId = :invoiceId ORDER BY paymentDate DESC")
    List<InvoicePayment> getPaymentsByInvoiceSync(int invoiceId);
    
    @Query("SELECT SUM(amount) FROM invoice_payments WHERE invoiceId = :invoiceId AND status = 'completed'")
    Double getTotalPaymentByInvoice(int invoiceId);
    
    @Query("SELECT * FROM invoice_payments WHERE status = :status ORDER BY paymentDate DESC")
    LiveData<List<InvoicePayment>> getPaymentsByStatus(String status);
    
    @Query("SELECT SUM(amount) FROM invoice_payments WHERE status = 'completed'")
    LiveData<Double> getTotalPaymentsReceived();
    
    @Query("DELETE FROM invoice_payments WHERE invoiceId = :invoiceId")
    void deleteByInvoiceId(int invoiceId);
    
    @Query("DELETE FROM invoice_payments WHERE id = :id")
    void deleteById(int id);
}
