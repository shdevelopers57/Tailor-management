package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.InvoiceDao;
import com.supereme.tailormanagement.database.entity.Invoice;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class InvoiceRepository {
    
    private InvoiceDao invoiceDao;
    private LiveData<List<Invoice>> allInvoices;
    
    public InvoiceRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        invoiceDao = db.invoiceDao();
        allInvoices = invoiceDao.getAllInvoices();
    }
    
    public void insert(Invoice invoice) {
        if (invoice != null) {
            RepositoryExecutor.execute(() -> invoiceDao.insert(invoice));
        }
    }
    
    public void update(Invoice invoice) {
        if (invoice != null) {
            RepositoryExecutor.execute(() -> invoiceDao.update(invoice));
        }
    }
    
    public void delete(Invoice invoice) {
        if (invoice != null) {
            RepositoryExecutor.execute(() -> invoiceDao.delete(invoice));
        }
    }
    
    public LiveData<List<Invoice>> getAllInvoices() {
        return allInvoices;
    }
    
    public LiveData<Invoice> getInvoiceById(int id) {
        return invoiceDao.getInvoiceById(id);
    }
    
    public Invoice getInvoiceByIdSync(int id) {
        return invoiceDao.getInvoiceByIdSync(id);
    }
    
    public Invoice getInvoiceByNumber(String invoiceNumber) {
        if (invoiceNumber == null || invoiceNumber.isEmpty()) return null;
        return invoiceDao.getInvoiceByNumber(invoiceNumber);
    }
    
    public LiveData<List<Invoice>> getInvoicesByCustomer(int customerId) {
        return invoiceDao.getInvoicesByCustomer(customerId);
    }
    
    public Invoice getInvoiceByOrder(int orderId) {
        return invoiceDao.getInvoiceByOrder(orderId);
    }
    
    public LiveData<List<Invoice>> getInvoicesByStatus(String status) {
        return invoiceDao.getInvoicesByStatus(status);
    }
    
    public LiveData<List<Invoice>> searchInvoices(String query) {
        return invoiceDao.searchInvoices(query);
    }
    
    public LiveData<Double> getTotalInvoiceAmount() {
        return invoiceDao.getTotalInvoiceAmount();
    }
    
    public LiveData<Double> getTotalPaidAmount() {
        return invoiceDao.getTotalPaidAmount();
    }
    
    public LiveData<Integer> getInvoiceCount() {
        return invoiceDao.getInvoiceCount();
    }
    
    public List<Invoice> getAllInvoicesSync() {
        return invoiceDao.getAllInvoicesSync();
    }
}
