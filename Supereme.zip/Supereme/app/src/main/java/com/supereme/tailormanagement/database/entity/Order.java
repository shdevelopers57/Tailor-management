package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "orders", foreignKeys = @ForeignKey(entity = Customer.class, 
        parentColumns = "id", childColumns = "customerId", onDelete = ForeignKey.CASCADE),
        indices = {@Index("customerId")})
public class Order {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public int customerId;
    public String orderType; // Suit, Shirt, Pant, etc.
    public String description;
    public Date orderDate;
    public Date deliveryDate;
    public double amount;
    public String status; // pending, designing, tailoring, fitting, completed, delivered, cancelled
    public double advance;
    public double remaining;
    public Date createdDate;
    public Date lastModified;
    
    public Order() {
        this.orderDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.status = "pending";
        this.remaining = this.amount - this.advance;
    }
    
    @Ignore
    public Order(int customerId, String orderType, String description, double amount) {
        this.customerId = customerId;
        this.orderType = orderType;
        this.description = description;
        this.amount = amount;
        this.orderDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.status = "pending";
        this.advance = 0;
        this.remaining = amount;
    }
    
    public void updateRemaining() {
        this.remaining = this.amount - this.advance;
    }
    
    @Override
    public String toString() {
        return "Order{" +
                "id=" + id +
                ", customerId=" + customerId +
                ", orderType='" + orderType + '\'' +
                ", status='" + status + '\'' +
                ", amount=" + amount +
                '}';
    }
}
