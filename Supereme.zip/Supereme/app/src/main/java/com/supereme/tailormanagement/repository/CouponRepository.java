package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.CouponDao;
import com.supereme.tailormanagement.database.entity.Coupon;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class CouponRepository {
    
    private CouponDao couponDao;
    private LiveData<List<Coupon>> allCoupons;
    
    public CouponRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        couponDao = db.couponDao();
        allCoupons = couponDao.getAllCoupons();
    }
    
    public void insert(Coupon coupon) {
        if (coupon != null) {
            RepositoryExecutor.execute(() -> couponDao.insert(coupon));
        }
    }
    
    public void update(Coupon coupon) {
        if (coupon != null) {
            RepositoryExecutor.execute(() -> couponDao.update(coupon));
        }
    }
    
    public void delete(Coupon coupon) {
        if (coupon != null) {
            RepositoryExecutor.execute(() -> couponDao.delete(coupon));
        }
    }
    
    public LiveData<List<Coupon>> getAllCoupons() {
        return allCoupons;
    }
    
    public LiveData<Coupon> getCouponById(int id) {
        return couponDao.getCouponById(id);
    }
    
    public Coupon getCouponByIdSync(int id) {
        return couponDao.getCouponByIdSync(id);
    }
    
    public Coupon getCouponByCode(String code) {
        if (code == null || code.isEmpty()) return null;
        return couponDao.getCouponByCode(code);
    }
    
    public LiveData<List<Coupon>> searchCoupons(String query) {
        return couponDao.searchCoupons(query);
    }
    
    public LiveData<List<Coupon>> getActiveCoupons() {
        return couponDao.getActiveCoupons();
    }
    
    public LiveData<Integer> getCouponCount() {
        return couponDao.getCouponCount();
    }
    
    public List<Coupon> getAllCouponsSync() {
        return couponDao.getAllCouponsSync();
    }
}
