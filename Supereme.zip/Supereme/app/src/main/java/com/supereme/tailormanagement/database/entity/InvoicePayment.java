package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "invoice_payments", 
        foreignKeys = @ForeignKey(entity = Invoice.class, 
                parentColumns = "id", 
                childColumns = "invoiceId", 
                onDelete = ForeignKey.CASCADE),
        indices = {@Index("invoiceId")})
public class InvoicePayment {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public int invoiceId;
    public double amount;
    public String paymentMethod; // Cash, Card, Bank Transfer, Cheque, Online
    public String transactionId;
    public String notes;
    public Date paymentDate;
    public String status; // pending, completed, failed, refunded
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public InvoicePayment() {
        this.paymentDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.status = "pending";
        this.isActive = true;
    }
    
    @Ignore
    public InvoicePayment(int invoiceId, double amount, String paymentMethod) {
        this.invoiceId = invoiceId;
        this.amount = amount;
        this.paymentMethod = paymentMethod;
        this.paymentDate = new Date();
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.status = "pending";
        this.isActive = true;
    }
    
    @Override
    public String toString() {
        return "InvoicePayment{" +
                "amount=" + amount +
                ", paymentMethod='" + paymentMethod + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
