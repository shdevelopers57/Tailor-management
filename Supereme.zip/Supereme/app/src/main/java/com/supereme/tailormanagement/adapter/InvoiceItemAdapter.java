package com.supereme.tailormanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.InvoiceItem;
import java.util.List;

public class InvoiceItemAdapter extends RecyclerView.Adapter<InvoiceItemAdapter.InvoiceItemViewHolder> {
    
    private Context context;
    private List<InvoiceItem> items;
    
    public InvoiceItemAdapter(Context context) {
        this.context = context;
    }
    
    public void setItems(List<InvoiceItem> items) {
        this.items = items;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public InvoiceItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_invoice_item, parent, false);
        return new InvoiceItemViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull InvoiceItemViewHolder holder, int position) {
        if (items == null || position >= items.size()) return;
        InvoiceItem item = items.get(position);
        holder.bind(item);
    }
    
    @Override
    public int getItemCount() {
        return items == null ? 0 : items.size();
    }
    
    public class InvoiceItemViewHolder extends RecyclerView.ViewHolder {
        private TextView description;
        private TextView quantity;
        private TextView unitPrice;
        private TextView amount;
        
        public InvoiceItemViewHolder(@NonNull View itemView) {
            super(itemView);
            description = itemView.findViewById(R.id.item_description);
            quantity = itemView.findViewById(R.id.item_quantity);
            unitPrice = itemView.findViewById(R.id.item_unit_price);
            amount = itemView.findViewById(R.id.item_amount);
        }
        
        public void bind(InvoiceItem item) {
            if (item == null) return;
            description.setText(item.description != null ? item.description : "");
            quantity.setText("Qty: " + item.quantity);
            unitPrice.setText("Rs. " + String.format("%.2f", item.unitPrice));
            amount.setText("Rs. " + String.format("%.2f", item.amount));
        }
    }
}
