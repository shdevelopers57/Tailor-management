package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Measurement;
import java.util.List;

@Dao
public interface MeasurementDao {
    
    @Insert
    long insert(Measurement measurement);
    
    @Update
    int update(Measurement measurement);
    
    @Delete
    int delete(Measurement measurement);
    
    @Query("SELECT * FROM measurements WHERE id = :id")
    LiveData<Measurement> getMeasurementById(int id);
    
    @Query("SELECT * FROM measurements WHERE id = :id")
    Measurement getMeasurementByIdSync(int id);
    
    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY id DESC LIMIT 1")
    LiveData<Measurement> getLatestMeasurementForCustomer(int customerId);
    
    @Query("SELECT * FROM measurements WHERE customerId = :customerId ORDER BY id DESC")
    LiveData<List<Measurement>> getMeasurementsByCustomerId(int customerId);
    
    @Query("SELECT * FROM measurements WHERE orderId = :orderId")
    LiveData<Measurement> getMeasurementByOrderId(int orderId);
    
    @Query("SELECT * FROM measurements WHERE orderId = :orderId")
    Measurement getMeasurementByOrderIdSync(int orderId);
    
    @Query("SELECT * FROM measurements ORDER BY id DESC")
    LiveData<List<Measurement>> getAllMeasurements();
    
    @Query("DELETE FROM measurements WHERE id = :id")
    void deleteById(int id);
}
