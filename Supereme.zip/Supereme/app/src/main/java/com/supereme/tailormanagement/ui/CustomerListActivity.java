package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.CustomerAdapter;
import com.supereme.tailormanagement.viewmodel.CustomerViewModel;
import android.widget.Toast;

public class CustomerListActivity extends AppCompatActivity {
    
    private CustomerViewModel customerViewModel;
    private RecyclerView rvCustomers;
    private TextInputEditText etSearch;
    private View layoutEmpty;
    private CustomerAdapter adapter;
    private boolean showMeasurements = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_customer_list);
            
            // Get the flag from intent
            Intent receivedIntent = getIntent();
            showMeasurements = receivedIntent != null && receivedIntent.getBooleanExtra("showMeasurements", false);
            
            customerViewModel = new ViewModelProvider(this).get(CustomerViewModel.class);
            
            initializeViews();
            setupRecyclerView();
            setupSearchListener();
            setupFAB();
            observeData();
        } catch (Exception e) {
            Log.e("CustomerListActivity", "Error initializing customer list", e);
            Toast.makeText(this, "کسی مسئلے کی وجہ سے کسٹمرز کی فہرست نہیں دکھائی جا سکی", Toast.LENGTH_LONG).show();
        }
    }
    
    private void initializeViews() {
        rvCustomers = findViewById(R.id.rv_customers);
        etSearch = findViewById(R.id.et_search);
        layoutEmpty = findViewById(R.id.layout_empty);
    }
    
    private void setupRecyclerView() {
        if (rvCustomers == null) return;
        adapter = new CustomerAdapter((customer, position) -> {
            if (customer == null) return;
            if (showMeasurements) {
                Intent intent = new Intent(CustomerListActivity.this, MeasurementActivity.class);
                intent.putExtra("customer_id", customer.id);
                startActivity(intent);
            } else {
                Intent intent = new Intent(CustomerListActivity.this, AddCustomerActivity.class);
                intent.putExtra("customer_id", customer.id);
                startActivity(intent);
            }
        });
        rvCustomers.setAdapter(adapter);
    }
    
    private void setupSearchListener() {
        if (etSearch == null) return;
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().isEmpty()) {
                    customerViewModel.getAllCustomers();
                } else {
                    customerViewModel.searchCustomers(s.toString());
                }
            }
            
            @Override
            public void afterTextChanged(Editable s) {}
        });
    }
    
    private void setupFAB() {
        FloatingActionButton fabAdd = findViewById(R.id.fab_add);
        if (fabAdd != null) {
            fabAdd.setOnClickListener(v -> {
                startActivity(new Intent(CustomerListActivity.this, AddCustomerActivity.class));
            });
        }
    }
    
    private void observeData() {
        if (customerViewModel == null || adapter == null || rvCustomers == null || layoutEmpty == null) return;
        customerViewModel.getAllCustomers().observe(this, customers -> {
            if (customers != null && !customers.isEmpty()) {
                adapter.setCustomers(customers);
                rvCustomers.setVisibility(View.VISIBLE);
                layoutEmpty.setVisibility(View.GONE);
            } else {
                adapter.setCustomers(new java.util.ArrayList<>());
                rvCustomers.setVisibility(View.GONE);
                layoutEmpty.setVisibility(View.VISIBLE);
            }
        });
    }
}
