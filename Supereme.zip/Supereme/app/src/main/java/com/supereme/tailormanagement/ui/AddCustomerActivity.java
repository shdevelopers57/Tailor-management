package com.supereme.tailormanagement.ui;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.google.android.material.textfield.TextInputEditText;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Customer;
import com.supereme.tailormanagement.viewmodel.CustomerViewModel;

public class AddCustomerActivity extends AppCompatActivity {
    
    private CustomerViewModel customerViewModel;
    private TextInputEditText etName, etPhone, etEmail, etAddress, etCity, etCountry;
    private Button btnSave, btnCancel, btnDelete;
    private Customer currentCustomer;
    private int customerId = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_customer);
        
        customerViewModel = new ViewModelProvider(this).get(CustomerViewModel.class);
        
        initializeViews();
        
        if (getIntent().hasExtra("customer_id")) {
            customerId = getIntent().getIntExtra("customer_id", -1);
            loadCustomerData(customerId);
            btnDelete.setVisibility(Button.VISIBLE);
        } else {
            getSupportActionBar().setTitle(R.string.add_customer);
        }
        
        setupClickListeners();
    }
    
    private void initializeViews() {
        etName = findViewById(R.id.et_name);
        etPhone = findViewById(R.id.et_phone);
        etEmail = findViewById(R.id.et_email);
        etAddress = findViewById(R.id.et_address);
        etCity = findViewById(R.id.et_city);
        etCountry = findViewById(R.id.et_country);
        btnSave = findViewById(R.id.btn_save);
        btnCancel = findViewById(R.id.btn_cancel);
        btnDelete = findViewById(R.id.btn_delete);
    }
    
    private void loadCustomerData(int customerId) {
        customerViewModel.getCustomerById(customerId).observe(this, customer -> {
            if (customer != null) {
                currentCustomer = customer;
                etName.setText(customer.name);
                etPhone.setText(customer.phone);
                etEmail.setText(customer.email);
                etAddress.setText(customer.address);
                etCity.setText(customer.city);
                etCountry.setText(customer.country);
                getSupportActionBar().setTitle(R.string.edit_customer);
            }
        });
    }
    
    private void setupClickListeners() {
        btnSave.setOnClickListener(v -> saveCustomer());
        btnCancel.setOnClickListener(v -> finish());
        btnDelete.setOnClickListener(v -> deleteCustomer());
    }
    
    private void saveCustomer() {
        String name = etName.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String address = etAddress.getText().toString().trim();
        String city = etCity.getText().toString().trim();
        String country = etCountry.getText().toString().trim();
        
        if (name.isEmpty()) {
            Toast.makeText(this, R.string.error_empty_fields, Toast.LENGTH_SHORT).show();
            return;
        }
        
        boolean isNewCustomer = customerId == -1;
        
        if (isNewCustomer) {
            // New customer
            Customer newCustomer = new Customer(name, phone, email, address);
            newCustomer.city = city;
            newCustomer.country = country;
            
            // Save customer and get ID for next step
            new Thread(() -> {
                customerViewModel.insertCustomer(newCustomer);
                
                // Get the newly created customer by phone number
                Customer savedCustomer = customerViewModel.getCustomerByPhoneSync(phone);
                
                runOnUiThread(() -> {
                    if (savedCustomer != null) {
                        Toast.makeText(AddCustomerActivity.this, R.string.customer_added, Toast.LENGTH_SHORT).show();
                        
                        // Navigate to measurement activity
                        Intent intent = new Intent(AddCustomerActivity.this, MeasurementActivity.class);
                        intent.putExtra("customer_id", savedCustomer.id);
                        intent.putExtra("new_customer", true);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(AddCustomerActivity.this, R.string.error_loading_data, Toast.LENGTH_SHORT).show();
                    }
                });
            }).start();
        } else {
            // Update existing customer
            currentCustomer.name = name;
            currentCustomer.phone = phone;
            currentCustomer.email = email;
            currentCustomer.address = address;
            currentCustomer.city = city;
            currentCustomer.country = country;
            customerViewModel.updateCustomer(currentCustomer);
            Toast.makeText(this, R.string.customer_updated, Toast.LENGTH_SHORT).show();
            finish();
        }
    }
    
    private void deleteCustomer() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirmation)
                .setMessage(R.string.delete_confirmation)
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    customerViewModel.deleteCustomer(currentCustomer);
                    Toast.makeText(AddCustomerActivity.this, R.string.success, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.no, null)
                .show();
    }
}
