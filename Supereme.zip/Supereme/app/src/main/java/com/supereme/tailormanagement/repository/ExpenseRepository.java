package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.ExpenseDao;
import com.supereme.tailormanagement.database.entity.Expense;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class ExpenseRepository {
    
    private ExpenseDao expenseDao;
    private LiveData<List<Expense>> allExpenses;
    
    public ExpenseRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        expenseDao = db.expenseDao();
        allExpenses = expenseDao.getAllExpenses();
    }
    
    public void insert(Expense expense) {
        if (expense != null) {
            RepositoryExecutor.execute(() -> expenseDao.insert(expense));
        }
    }
    
    public void update(Expense expense) {
        if (expense != null) {
            RepositoryExecutor.execute(() -> expenseDao.update(expense));
        }
    }
    
    public void delete(Expense expense) {
        if (expense != null) {
            RepositoryExecutor.execute(() -> expenseDao.delete(expense));
        }
    }
    
    public LiveData<List<Expense>> getAllExpenses() {
        return allExpenses;
    }
    
    public LiveData<Expense> getExpenseById(int id) {
        return expenseDao.getExpenseById(id);
    }
    
    public Expense getExpenseByIdSync(int id) {
        return expenseDao.getExpenseByIdSync(id);
    }
    
    public LiveData<List<Expense>> getExpensesByCategory(String category) {
        return expenseDao.getExpensesByCategory(category);
    }
    
    public LiveData<List<Expense>> searchExpenses(String query) {
        return expenseDao.searchExpenses(query);
    }
    
    public LiveData<Double> getTotalExpenses() {
        return expenseDao.getTotalExpenses();
    }
    
    public LiveData<List<String>> getAllCategories() {
        return expenseDao.getAllCategories();
    }
    
    public LiveData<Integer> getExpenseCount() {
        return expenseDao.getExpenseCount();
    }
    
    public List<Expense> getAllExpensesSync() {
        return expenseDao.getAllExpensesSync();
    }
}
