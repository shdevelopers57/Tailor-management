package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "measurement_units")
public class MeasurementUnit {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String unit; // cm, inch, mm
    public String symbol;
    public String description;
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public MeasurementUnit() {
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Ignore
    public MeasurementUnit(String unit, String symbol) {
        this.unit = unit;
        this.symbol = symbol;
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Override
    public String toString() {
        return symbol;
    }
}
