package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Ignore;
import androidx.room.Index;
import androidx.room.PrimaryKey;

@Entity(tableName = "measurements", foreignKeys = {
        @ForeignKey(entity = Customer.class, parentColumns = "id", childColumns = "customerId", onDelete = ForeignKey.CASCADE),
        @ForeignKey(entity = Order.class, parentColumns = "id", childColumns = "orderId", onDelete = ForeignKey.CASCADE)
},
        indices = {@Index("customerId"), @Index("orderId")})
public class Measurement {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public int customerId;
    public int orderId;
    
    // General measurements in cm
    public double chest;
    public double waist;
    public double hips;
    public double shoulder;
    public double sleeveLength;
    public double totalLength;
    public double inseam;
    
    // Additional measurements
    public double neckSize;
    public double armholeDepth;
    public double backWidth;
    public double frontWidth;
    
    public String notes;
    
    public Measurement() {
    }
    
    @Ignore
    public Measurement(int customerId, int orderId) {
        this.customerId = customerId;
        this.orderId = orderId;
    }
    
    @Override
    public String toString() {
        return "Measurement{" +
                "id=" + id +
                ", chest=" + chest +
                ", waist=" + waist +
                '}';
    }
}
