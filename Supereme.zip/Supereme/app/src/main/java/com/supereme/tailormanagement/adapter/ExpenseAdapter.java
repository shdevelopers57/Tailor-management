package com.supereme.tailormanagement.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Expense;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ExpenseViewHolder> {
    
    private Context context;
    private List<Expense> expenses;
    private OnExpenseClickListener listener;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
    
    public interface OnExpenseClickListener {
        void onEdit(Expense expense);
        void onDelete(Expense expense);
    }
    
    public ExpenseAdapter(Context context, OnExpenseClickListener listener) {
        this.context = context;
        this.listener = listener;
    }
    
    public void setExpenses(List<Expense> expenses) {
        this.expenses = expenses;
        notifyDataSetChanged();
    }
    
    @NonNull
    @Override
    public ExpenseViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_expense, parent, false);
        return new ExpenseViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull ExpenseViewHolder holder, int position) {
        if (expenses == null || position >= expenses.size()) return;
        Expense expense = expenses.get(position);
        holder.bind(expense);
    }
    
    @Override
    public int getItemCount() {
        return expenses == null ? 0 : expenses.size();
    }
    
    public class ExpenseViewHolder extends RecyclerView.ViewHolder {
        private TextView expenseTitle;
        private TextView expenseCategory;
        private TextView expenseAmount;
        private TextView expenseDate;
        private ImageView editButton;
        private ImageView deleteButton;
        
        public ExpenseViewHolder(@NonNull View itemView) {
            super(itemView);
            expenseTitle = itemView.findViewById(R.id.expense_title);
            expenseCategory = itemView.findViewById(R.id.expense_category);
            expenseAmount = itemView.findViewById(R.id.expense_amount);
            expenseDate = itemView.findViewById(R.id.expense_date);
            editButton = itemView.findViewById(R.id.btn_edit);
            deleteButton = itemView.findViewById(R.id.btn_delete);
        }
        
        public void bind(Expense expense) {
            if (expense == null) return;
            expenseTitle.setText(expense.title != null ? expense.title : "");
            expenseCategory.setText("Category: " + (expense.category != null ? expense.category : ""));
            expenseAmount.setText("Rs. " + String.format("%.2f", expense.amount));
            if (expense.expenseDate != null) {
                expenseDate.setText(dateFormat.format(expense.expenseDate));
            } else {
                expenseDate.setText("");
            }
            
            editButton.setOnClickListener(v -> listener.onEdit(expense));
            deleteButton.setOnClickListener(v -> listener.onDelete(expense));
        }
    }
}
