package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.ExpenseAdapter;
import com.supereme.tailormanagement.database.entity.Expense;
import com.supereme.tailormanagement.viewmodel.ExpenseViewModel;

public class ExpenseListActivity extends AppCompatActivity implements ExpenseAdapter.OnExpenseClickListener {
    
    private RecyclerView recyclerView;
    private Button addButton;
    private ExpenseAdapter adapter;
    private ExpenseViewModel viewModel;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expense_list);
        
        setTitle("Expenses");
        
        recyclerView = findViewById(R.id.recycler_view);
        addButton = findViewById(R.id.btn_add);
        
        setupRecyclerView();
        setupViewModel();
        
        addButton.setOnClickListener(v -> startActivity(new Intent(this, AddExpenseActivity.class)));
    }
    
    private void setupRecyclerView() {
        adapter = new ExpenseAdapter(this, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }
    
    private void setupViewModel() {
        viewModel = new ViewModelProvider(this).get(ExpenseViewModel.class);
        viewModel.getAllExpenses().observe(this, expenses -> {
            adapter.setExpenses(expenses);
        });
    }
    
    @Override
    public void onEdit(Expense expense) {
        Intent intent = new Intent(this, AddExpenseActivity.class);
        intent.putExtra("expense_id", expense.id);
        startActivity(intent);
    }
    
    @Override
    public void onDelete(Expense expense) {
        viewModel.deleteExpense(expense);
        Toast.makeText(this, "Expense deleted", Toast.LENGTH_SHORT).show();
    }
}
