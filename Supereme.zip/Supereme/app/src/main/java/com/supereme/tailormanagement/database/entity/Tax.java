package com.supereme.tailormanagement.database.entity;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
import java.util.Date;

@Entity(tableName = "taxes")
public class Tax {
    @PrimaryKey(autoGenerate = true)
    public int id;
    
    public String name;
    public double rate; // Percentage
    public String description;
    public boolean isActive;
    public Date createdDate;
    public Date lastModified;
    
    public Tax() {
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Ignore
    public Tax(String name, double rate) {
        this.name = name;
        this.rate = rate;
        this.createdDate = new Date();
        this.lastModified = new Date();
        this.isActive = true;
    }
    
    @Override
    public String toString() {
        return name + " (" + rate + "%)";
    }
}
