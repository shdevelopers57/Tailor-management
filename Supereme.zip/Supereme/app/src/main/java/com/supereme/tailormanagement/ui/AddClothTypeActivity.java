package com.supereme.tailormanagement.ui;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.ClothType;
import com.supereme.tailormanagement.viewmodel.ClothTypeViewModel;

public class AddClothTypeActivity extends AppCompatActivity {
    
    private EditText nameInput;
    private EditText descriptionInput;
    private EditText priceInput;
    private Button saveButton;
    private ClothTypeViewModel viewModel;
    private Integer clothTypeId;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_cloth_type);
        
        nameInput = findViewById(R.id.cloth_type_name_input);
        descriptionInput = findViewById(R.id.cloth_type_description_input);
        priceInput = findViewById(R.id.cloth_type_price_input);
        saveButton = findViewById(R.id.btn_save);
        
        viewModel = new ViewModelProvider(this).get(ClothTypeViewModel.class);
        
        clothTypeId = getIntent().getIntExtra("cloth_type_id", -1);
        if (clothTypeId != -1) {
            setTitle("Edit Cloth Type");
            loadClothType(clothTypeId);
        } else {
            setTitle("Add Cloth Type");
        }
        
        saveButton.setOnClickListener(v -> saveClothType());
    }
    
    private void loadClothType(int id) {
        viewModel.getClothTypeById(id).observe(this, clothType -> {
            if (clothType != null) {
                nameInput.setText(clothType.name);
                descriptionInput.setText(clothType.description);
                priceInput.setText(String.valueOf(clothType.defaultPrice));
            }
        });
    }
    
    private void saveClothType() {
        String name = nameInput.getText().toString().trim();
        String description = descriptionInput.getText().toString().trim();
        String priceStr = priceInput.getText().toString().trim();
        
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter cloth type name", Toast.LENGTH_SHORT).show();
            return;
        }
        
        if (priceStr.isEmpty()) {
            Toast.makeText(this, "Please enter price", Toast.LENGTH_SHORT).show();
            return;
        }
        
        try {
            double price = Double.parseDouble(priceStr);
            
            ClothType clothType = new ClothType(name, description, price);
            if (clothTypeId != -1) {
                clothType.id = clothTypeId;
                viewModel.updateClothType(clothType);
                Toast.makeText(this, "Cloth type updated", Toast.LENGTH_SHORT).show();
            } else {
                viewModel.insertClothType(clothType);
                Toast.makeText(this, "Cloth type added", Toast.LENGTH_SHORT).show();
            }
            finish();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid price format", Toast.LENGTH_SHORT).show();
        }
    }
}
