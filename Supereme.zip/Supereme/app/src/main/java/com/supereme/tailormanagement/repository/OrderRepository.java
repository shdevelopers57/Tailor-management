package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.OrderDao;
import com.supereme.tailormanagement.database.entity.Order;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class OrderRepository {
    
    private OrderDao orderDao;
    private LiveData<List<Order>> allOrders;
    
    public OrderRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        orderDao = db.orderDao();
        allOrders = orderDao.getAllOrders();
    }
    
    public void insert(Order order) {
        if (order != null) {
            RepositoryExecutor.execute(() -> orderDao.insert(order));
        }
    }
    
    public void update(Order order) {
        if (order != null) {
            RepositoryExecutor.execute(() -> orderDao.update(order));
        }
    }
    
    public void delete(Order order) {
        if (order != null) {
            RepositoryExecutor.execute(() -> orderDao.delete(order));
        }
    }
    
    public LiveData<List<Order>> getAllOrders() {
        return allOrders;
    }
    
    public LiveData<Order> getOrderById(int id) {
        return orderDao.getOrderById(id);
    }
    
    public Order getOrderByIdSync(int id) {
        return orderDao.getOrderByIdSync(id);
    }
    
    public LiveData<List<Order>> getOrdersByCustomerId(int customerId) {
        return orderDao.getOrdersByCustomerId(customerId);
    }
    
    public List<Order> getOrdersByCustomerIdSync(int customerId) {
        return orderDao.getOrdersByCustomerIdSync(customerId);
    }
    
    public LiveData<List<Order>> getOrdersByStatus(String status) {
        return orderDao.getOrdersByStatus(status);
    }
    
    public List<Order> getOrdersByStatusSync(String status) {
        return orderDao.getOrdersByStatusSync(status);
    }
    
    public LiveData<Integer> getOrderCountByStatus(String status) {
        return orderDao.getOrderCountByStatus(status);
    }
    
    public LiveData<Double> getTotalCompletedAmount() {
        return orderDao.getTotalCompletedAmount();
    }
    
    public Double getTotalPendingAmount() {
        Double result = orderDao.getTotalPendingAmount();
        return result != null ? result : 0.0;
    }
    
    public LiveData<List<Order>> getRecentOrders() {
        return orderDao.getRecentOrders();
    }
}
