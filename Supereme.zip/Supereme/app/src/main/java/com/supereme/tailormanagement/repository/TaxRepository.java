package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.TaxDao;
import com.supereme.tailormanagement.database.entity.Tax;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class TaxRepository {
    
    private TaxDao taxDao;
    private LiveData<List<Tax>> allTaxes;
    
    public TaxRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        taxDao = db.taxDao();
        allTaxes = taxDao.getAllTaxes();
    }
    
    public void insert(Tax tax) {
        if (tax != null) {
            RepositoryExecutor.execute(() -> taxDao.insert(tax));
        }
    }
    
    public void update(Tax tax) {
        if (tax != null) {
            RepositoryExecutor.execute(() -> taxDao.update(tax));
        }
    }
    
    public void delete(Tax tax) {
        if (tax != null) {
            RepositoryExecutor.execute(() -> taxDao.delete(tax));
        }
    }
    
    public LiveData<List<Tax>> getAllTaxes() {
        return allTaxes;
    }
    
    public LiveData<Tax> getTaxById(int id) {
        return taxDao.getTaxById(id);
    }
    
    public Tax getTaxByIdSync(int id) {
        return taxDao.getTaxByIdSync(id);
    }
    
    public LiveData<List<Tax>> searchTaxes(String query) {
        return taxDao.searchTaxes(query);
    }
    
    public LiveData<Integer> getTaxCount() {
        return taxDao.getTaxCount();
    }
    
    public List<Tax> getAllTaxesSync() {
        return taxDao.getAllTaxesSync();
    }
}
