package com.supereme.tailormanagement.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.card.MaterialCardView;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.database.entity.Customer;
import java.util.ArrayList;
import java.util.List;

public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.CustomerViewHolder> {
    
    private List<Customer> customers = new ArrayList<>();
    private OnCustomerClickListener onCustomerClickListener;
    
    public interface OnCustomerClickListener {
        void onCustomerClick(Customer customer, int position);
    }
    
    public CustomerAdapter(OnCustomerClickListener onCustomerClickListener) {
        this.onCustomerClickListener = onCustomerClickListener;
    }
    
    @NonNull
    @Override
    public CustomerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MaterialCardView cardView = new MaterialCardView(parent.getContext());
        cardView.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        cardView.setContentPadding(16, 16, 16, 16);
        cardView.setCardElevation(4);
        cardView.setRadius(8);
        
        LinearLayout linearLayout = new LinearLayout(parent.getContext());
        linearLayout.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        cardView.addView(linearLayout);
        
        return new CustomerViewHolder(cardView, linearLayout);
    }
    
    @Override
    public void onBindViewHolder(@NonNull CustomerViewHolder holder, int position) {
        Customer customer = customers.get(position);
        holder.bind(customer, position);
    }
    
    @Override
    public int getItemCount() {
        return customers.size();
    }
    
    public void setCustomers(List<Customer> customers) {
        this.customers = customers != null ? customers : new ArrayList<>();
        notifyDataSetChanged();
    }
    
    class CustomerViewHolder extends RecyclerView.ViewHolder {
        private MaterialCardView cardView;
        private LinearLayout container;
        private TextView tvName, tvPhone, tvAddress;
        
        public CustomerViewHolder(MaterialCardView cardView, LinearLayout container) {
            super(cardView);
            this.cardView = cardView;
            this.container = container;
            
            tvName = new TextView(cardView.getContext());
            tvName.setTextSize(16);
            tvName.setTextColor(cardView.getContext().getColor(R.color.text_primary));
            tvName.setTypeface(null, android.graphics.Typeface.BOLD);
            container.addView(tvName);
            
            tvPhone = new TextView(cardView.getContext());
            tvPhone.setTextSize(14);
            tvPhone.setTextColor(cardView.getContext().getColor(R.color.text_secondary));
            container.addView(tvPhone);
            
            tvAddress = new TextView(cardView.getContext());
            tvAddress.setTextSize(12);
            tvAddress.setTextColor(cardView.getContext().getColor(R.color.text_hint));
            container.addView(tvAddress);
            
            cardView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    onCustomerClickListener.onCustomerClick(customers.get(position), position);
                }
            });
        }
        
        public void bind(Customer customer, int position) {
            tvName.setText(customer.name);
            tvPhone.setText(customer.phone != null ? customer.phone : "");
            tvAddress.setText(customer.address != null ? customer.address : "");
        }
    }
}
