package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.Tax;
import com.supereme.tailormanagement.repository.TaxRepository;
import java.util.List;

public class TaxViewModel extends AndroidViewModel {
    
    private TaxRepository repository;
    private LiveData<List<Tax>> allTaxes;
    
    public TaxViewModel(Application application) {
        super(application);
        repository = new TaxRepository(application);
        allTaxes = repository.getAllTaxes();
    }
    
    public LiveData<List<Tax>> getAllTaxes() {
        return allTaxes;
    }
    
    public LiveData<Tax> getTaxById(int id) {
        return repository.getTaxById(id);
    }
    
    public LiveData<List<Tax>> searchTaxes(String query) {
        return repository.searchTaxes(query);
    }
    
    public void insertTax(Tax tax) {
        repository.insert(tax);
    }
    
    public void updateTax(Tax tax) {
        repository.update(tax);
    }
    
    public void deleteTax(Tax tax) {
        repository.delete(tax);
    }
}
