package com.supereme.tailormanagement.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.entity.ClothType;
import com.supereme.tailormanagement.repository.ClothTypeRepository;
import java.util.List;

public class ClothTypeViewModel extends AndroidViewModel {
    
    private ClothTypeRepository repository;
    private LiveData<List<ClothType>> allClothTypes;
    
    public ClothTypeViewModel(Application application) {
        super(application);
        repository = new ClothTypeRepository(application);
        allClothTypes = repository.getAllClothTypes();
    }
    
    public LiveData<List<ClothType>> getAllClothTypes() {
        return allClothTypes;
    }
    
    public LiveData<ClothType> getClothTypeById(int id) {
        return repository.getClothTypeById(id);
    }
    
    public LiveData<List<ClothType>> searchClothTypes(String query) {
        return repository.searchClothTypes(query);
    }
    
    public void insertClothType(ClothType clothType) {
        repository.insert(clothType);
    }
    
    public void updateClothType(ClothType clothType) {
        repository.update(clothType);
    }
    
    public void deleteClothType(ClothType clothType) {
        repository.delete(clothType);
    }
}
