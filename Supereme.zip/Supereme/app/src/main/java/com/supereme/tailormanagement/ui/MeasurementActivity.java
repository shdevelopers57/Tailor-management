package com.supereme.tailormanagement.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.supereme.tailormanagement.R;
import com.supereme.tailormanagement.adapter.MeasurementAdapter;
import com.supereme.tailormanagement.database.entity.Measurement;
import com.supereme.tailormanagement.viewmodel.MeasurementViewModel;

public class MeasurementActivity extends AppCompatActivity {
    
    private MeasurementViewModel measurementViewModel;
    private RecyclerView measurementRecyclerView;
    private FloatingActionButton fabAddMeasurement;
    private MeasurementAdapter measurementAdapter;
    private int customerId = -1;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_measurement_list);
            
            Intent intent = getIntent();
            customerId = intent != null ? intent.getIntExtra("customer_id", -1) : -1;
            
            measurementViewModel = new ViewModelProvider(this).get(MeasurementViewModel.class);
            
            initializeViews();
            setupRecyclerView();
            observeMeasurements();
            setupFabListener();
            
            if (customerId == -1) {
                Toast.makeText(this, "پہلے کوئی کسٹمر منتخب کریں", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Log.e("MeasurementActivity", "Error initializing measurement screen", e);
            Toast.makeText(this, "پیمائشوں کی اسکرین کھولنے میں مسئلہ ہوا", Toast.LENGTH_LONG).show();
        }
    }
    
    private void initializeViews() {
        measurementRecyclerView = findViewById(R.id.recycler_measurements);
        fabAddMeasurement = findViewById(R.id.fab_add_measurement);
    }
    
    private void setupRecyclerView() {
        if (measurementRecyclerView == null) return;
        measurementRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        measurementAdapter = new MeasurementAdapter((measurement, position) -> {
            if (measurement == null) return;
            Toast.makeText(MeasurementActivity.this, "پیمانہ منتخب کیا: " + measurement.id, Toast.LENGTH_SHORT).show();
        });
        measurementRecyclerView.setAdapter(measurementAdapter);
    }
    
    private void observeMeasurements() {
        if (measurementViewModel == null || measurementAdapter == null) return;
        if (customerId != -1) {
            measurementViewModel.getMeasurementsByCustomerId(customerId).observe(this, measurements -> {
                if (measurements != null && !measurements.isEmpty()) {
                    measurementAdapter.setMeasurements(measurements);
                } else {
                    measurementAdapter.setMeasurements(new java.util.ArrayList<>());
                }
            });
        } else {
            measurementAdapter.setMeasurements(new java.util.ArrayList<>());
        }
    }
    
    private void setupFabListener() {
        if (fabAddMeasurement == null) return;
        fabAddMeasurement.setOnClickListener(v -> {
            if (customerId == -1) {
                Toast.makeText(this, "پہلے کوئی کسٹمر منتخب کریں", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(MeasurementActivity.this, AddMeasurementActivity.class);
            intent.putExtra("customer_id", customerId);
            startActivity(intent);
        });
    }
}
