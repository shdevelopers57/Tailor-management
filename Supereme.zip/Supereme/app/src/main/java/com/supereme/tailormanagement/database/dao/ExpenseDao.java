package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Expense;
import java.util.List;

@Dao
public interface ExpenseDao {
    
    @Insert
    long insert(Expense expense);
    
    @Update
    int update(Expense expense);
    
    @Delete
    int delete(Expense expense);
    
    @Query("SELECT * FROM expenses WHERE id = :id")
    LiveData<Expense> getExpenseById(int id);
    
    @Query("SELECT * FROM expenses WHERE id = :id")
    Expense getExpenseByIdSync(int id);
    
    @Query("SELECT * FROM expenses WHERE isActive = 1 ORDER BY expenseDate DESC")
    LiveData<List<Expense>> getAllExpenses();
    
    @Query("SELECT * FROM expenses WHERE isActive = 1 ORDER BY expenseDate DESC")
    List<Expense> getAllExpensesSync();
    
    @Query("SELECT * FROM expenses WHERE category = :category AND isActive = 1 ORDER BY expenseDate DESC")
    LiveData<List<Expense>> getExpensesByCategory(String category);
    
    @Query("SELECT * FROM expenses WHERE title LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY expenseDate DESC")
    LiveData<List<Expense>> searchExpenses(String searchQuery);
    
    @Query("SELECT SUM(amount) FROM expenses WHERE isActive = 1")
    LiveData<Double> getTotalExpenses();
    
    @Query("SELECT SUM(amount) FROM expenses WHERE category = :category AND isActive = 1")
    Double getTotalExpensesByCategory(String category);
    
    @Query("SELECT DISTINCT category FROM expenses WHERE isActive = 1 ORDER BY category ASC")
    LiveData<List<String>> getAllCategories();
    
    @Query("SELECT COUNT(*) FROM expenses WHERE isActive = 1")
    LiveData<Integer> getExpenseCount();
    
    @Query("DELETE FROM expenses WHERE id = :id")
    void deleteById(int id);
}
