package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.MeasurementDao;
import com.supereme.tailormanagement.database.entity.Measurement;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class MeasurementRepository {
    
    private MeasurementDao measurementDao;
    private LiveData<List<Measurement>> allMeasurements;
    
    public MeasurementRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        measurementDao = db.measurementDao();
        allMeasurements = measurementDao.getAllMeasurements();
    }
    
    public void insert(Measurement measurement) {
        if (measurement != null) {
            RepositoryExecutor.execute(() -> measurementDao.insert(measurement));
        }
    }
    
    public void update(Measurement measurement) {
        if (measurement != null) {
            RepositoryExecutor.execute(() -> measurementDao.update(measurement));
        }
    }
    
    public void delete(Measurement measurement) {
        if (measurement != null) {
            RepositoryExecutor.execute(() -> measurementDao.delete(measurement));
        }
    }
    
    public LiveData<List<Measurement>> getAllMeasurements() {
        return allMeasurements;
    }
    
    public LiveData<Measurement> getMeasurementById(int id) {
        return measurementDao.getMeasurementById(id);
    }
    
    public Measurement getMeasurementByIdSync(int id) {
        return measurementDao.getMeasurementByIdSync(id);
    }
    
    public LiveData<Measurement> getLatestMeasurementForCustomer(int customerId) {
        return measurementDao.getLatestMeasurementForCustomer(customerId);
    }
    
    public LiveData<List<Measurement>> getMeasurementsByCustomerId(int customerId) {
        return measurementDao.getMeasurementsByCustomerId(customerId);
    }
    
    public LiveData<Measurement> getMeasurementByOrderId(int orderId) {
        return measurementDao.getMeasurementByOrderId(orderId);
    }
    
    public Measurement getMeasurementByOrderIdSync(int orderId) {
        return measurementDao.getMeasurementByOrderIdSync(orderId);
    }
}
