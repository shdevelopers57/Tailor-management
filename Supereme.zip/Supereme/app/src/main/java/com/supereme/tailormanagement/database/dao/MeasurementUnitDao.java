package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.MeasurementUnit;
import java.util.List;

@Dao
public interface MeasurementUnitDao {
    
    @Insert
    long insert(MeasurementUnit unit);
    
    @Update
    int update(MeasurementUnit unit);
    
    @Delete
    int delete(MeasurementUnit unit);
    
    @Query("SELECT * FROM measurement_units WHERE id = :id")
    LiveData<MeasurementUnit> getUnitById(int id);
    
    @Query("SELECT * FROM measurement_units WHERE id = :id")
    MeasurementUnit getUnitByIdSync(int id);
    
    @Query("SELECT * FROM measurement_units WHERE isActive = 1 ORDER BY unit ASC")
    LiveData<List<MeasurementUnit>> getAllUnits();
    
    @Query("SELECT * FROM measurement_units WHERE isActive = 1 ORDER BY unit ASC")
    List<MeasurementUnit> getAllUnitsSync();
    
    @Query("SELECT * FROM measurement_units WHERE unit LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY unit ASC")
    LiveData<List<MeasurementUnit>> searchUnits(String searchQuery);
    
    @Query("SELECT COUNT(*) FROM measurement_units WHERE isActive = 1")
    LiveData<Integer> getUnitCount();
    
    @Query("DELETE FROM measurement_units WHERE id = :id")
    void deleteById(int id);
}
