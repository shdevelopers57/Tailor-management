package com.supereme.tailormanagement.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.supereme.tailormanagement.database.entity.Coupon;
import java.util.List;

@Dao
public interface CouponDao {
    
    @Insert
    long insert(Coupon coupon);
    
    @Update
    int update(Coupon coupon);
    
    @Delete
    int delete(Coupon coupon);
    
    @Query("SELECT * FROM coupons WHERE id = :id")
    LiveData<Coupon> getCouponById(int id);
    
    @Query("SELECT * FROM coupons WHERE id = :id")
    Coupon getCouponByIdSync(int id);
    
    @Query("SELECT * FROM coupons WHERE code = :code")
    Coupon getCouponByCode(String code);
    
    @Query("SELECT * FROM coupons WHERE isActive = 1 ORDER BY code ASC")
    LiveData<List<Coupon>> getAllCoupons();
    
    @Query("SELECT * FROM coupons WHERE isActive = 1 ORDER BY code ASC")
    List<Coupon> getAllCouponsSync();
    
    @Query("SELECT * FROM coupons WHERE code LIKE '%' || :searchQuery || '%' AND isActive = 1 ORDER BY code ASC")
    LiveData<List<Coupon>> searchCoupons(String searchQuery);
    
    @Query("SELECT * FROM coupons WHERE isActive = 1 AND datetime('now') BETWEEN datetime(validFrom) AND datetime(validUpto) ORDER BY code ASC")
    LiveData<List<Coupon>> getActiveCoupons();
    
    @Query("SELECT COUNT(*) FROM coupons WHERE isActive = 1")
    LiveData<Integer> getCouponCount();
    
    @Query("DELETE FROM coupons WHERE id = :id")
    void deleteById(int id);
}
