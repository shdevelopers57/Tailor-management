package com.supereme.tailormanagement.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.supereme.tailormanagement.database.TailorManagementDatabase;
import com.supereme.tailormanagement.database.dao.InvoicePaymentDao;
import com.supereme.tailormanagement.database.entity.InvoicePayment;
import com.supereme.tailormanagement.util.RepositoryExecutor;
import java.util.List;

public class InvoicePaymentRepository {
    
    private InvoicePaymentDao invoicePaymentDao;
    
    public InvoicePaymentRepository(Application application) {
        TailorManagementDatabase db = TailorManagementDatabase.getInstance(application);
        invoicePaymentDao = db.invoicePaymentDao();
    }
    
    public void insert(InvoicePayment payment) {
        if (payment != null) {
            RepositoryExecutor.execute(() -> invoicePaymentDao.insert(payment));
        }
    }
    
    public void update(InvoicePayment payment) {
        if (payment != null) {
            RepositoryExecutor.execute(() -> invoicePaymentDao.update(payment));
        }
    }
    
    public void delete(InvoicePayment payment) {
        if (payment != null) {
            RepositoryExecutor.execute(() -> invoicePaymentDao.delete(payment));
        }
    }
    
    public LiveData<InvoicePayment> getPaymentById(int id) {
        return invoicePaymentDao.getPaymentById(id);
    }
    
    public InvoicePayment getPaymentByIdSync(int id) {
        return invoicePaymentDao.getPaymentByIdSync(id);
    }
    
    public LiveData<List<InvoicePayment>> getPaymentsByInvoice(int invoiceId) {
        return invoicePaymentDao.getPaymentsByInvoice(invoiceId);
    }
    
    public List<InvoicePayment> getPaymentsByInvoiceSync(int invoiceId) {
        return invoicePaymentDao.getPaymentsByInvoiceSync(invoiceId);
    }
    
    public Double getTotalPaymentByInvoice(int invoiceId) {
        Double result = invoicePaymentDao.getTotalPaymentByInvoice(invoiceId);
        return result != null ? result : 0.0;
    }
    
    public LiveData<List<InvoicePayment>> getPaymentsByStatus(String status) {
        return invoicePaymentDao.getPaymentsByStatus(status);
    }
    
    public LiveData<Double> getTotalPaymentsReceived() {
        return invoicePaymentDao.getTotalPaymentsReceived();
    }
}
